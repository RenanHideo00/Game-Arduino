#ifndef BREAKOUT_H           // Guarda de inclusão: só compila se BREAKOUT_H ainda não foi definido
#define BREAKOUT_H           // Define BREAKOUT_H para o arquivo não ser incluído duas vezes

#include <Arduino.h>         // Funções básicas do Arduino (millis, delay, itoa...)
#include <U8g2lib.h>         // Biblioteca gráfica do display OLED

// As linhas "extern" avisam que estas coisas já existem no arquivo principal (.ino)
extern U8G2_SSD1306_128X64_NONAME_F_HW_I2C u8g2;     // O objeto do display
extern bool btnPressed(uint8_t pin);                 // Detecta o instante em que um botão é apertado
extern bool btnHeld(uint8_t pin);                    // Detecta se um botão está sendo segurado
extern void beep(uint16_t freq, uint16_t ms);        // Toca um som no buzzer
extern void waitRelease();                           // Espera soltar todos os botões
extern void centreStr(const char *s, uint8_t y);     // Escreve texto centralizado
extern void gameOver(uint16_t score);                // Tela de Game Over com a pontuação

#define BRK_COLS 10          // Quantidade de tijolos por linha
#define BRK_ROWS 4           // Quantidade de linhas de tijolos
#define BRK_BW 11            // Largura de cada tijolo (pixels)
#define BRK_BH 5             // Altura de cada tijolo (pixels)
#define BRK_PADW 20          // Largura da raquete (pixels)
#define BRK_PADH 3           // Altura da raquete (pixels)

// Função principal do jogo; é chamada pelo menu e retorna quando o jogo termina
void game_breakout() {
  uint8_t bricks[BRK_ROWS][BRK_COLS];          // Matriz dos tijolos: 1 = existe, 0 = quebrado
  for (int r = 0; r < BRK_ROWS; r++)           // Percorre cada linha...
    for (int c = 0; c < BRK_COLS; c++)         // ...e cada coluna...
      bricks[r][c] = 1;                        // ...e coloca um tijolo inteiro
  int bricksLeft = BRK_ROWS * BRK_COLS;        // Contador de tijolos restantes (começa com todos: 40)
  int padX = (SCREEN_W - BRK_PADW) / 2;        // Posição X da raquete: começa centralizada
  const int padY = SCREEN_H - 6;               // Posição Y da raquete: fixa, perto da base da tela
  float bx = 64, by = 48;                      // Posição inicial da bolinha
  float vx = 1.7f, vy = -0.5f;                 // Velocidade inicial da bolinha (vy negativo = sobe)
  int lives = 3;                               // Número de vidas
  uint16_t score = 0;                          // Pontuação
  uint32_t lastFrame = millis();               // Momento do último frame (para calcular dt)

  // ── Tela de instruções ──
  u8g2.clearBuffer();                          // Limpa o buffer da tela
  u8g2.setFont(u8g2_font_ncenB10_tr);          // Fonte grande para o título
  centreStr("BREAKOUT", 24);                   // Título centralizado
  u8g2.setFont(u8g2_font_6x10_tr);             // Fonte pequena para as instruções
  centreStr("LEFT/RIGHT = paddle", 40);        // Explica os controles
  centreStr("Don't drop the ball!", 54);       // Objetivo
  u8g2.sendBuffer();                           // Envia o buffer para o display
  delay(1500);                                 // Deixa o jogador ler por 1,5 segundo
  waitRelease();                               // Garante que nenhum botão esteja apertado ao começar

  // ── Loop principal do jogo (1 volta = 1 frame) ──
  while (true) {
    uint32_t now = millis();                   // Hora atual em ms
    float dt = (now - lastFrame) / 30.0f;      // Fator de tempo desde o último frame (mantém a velocidade constante)
    lastFrame = now;                           // Guarda a hora deste frame

    // Movimento da raquete
    if (btnHeld(BTN_LEFT))                     // Se ESQUERDA está segurado...
      padX = max(0, padX - 4);                 // ...move 4 px para a esquerda, sem passar da borda
    if (btnHeld(BTN_RIGHT))                    // Se DIREITA está segurado...
      padX = min(SCREEN_W - BRK_PADW, padX + 4); // ...move 4 px para a direita, sem passar da borda

    // Movimento da bolinha
    bx += vx * dt;                             // Atualiza X conforme velocidade e tempo
    by += vy * dt;                             // Atualiza Y conforme velocidade e tempo

    // Rebote nas paredes
    if (bx <= 1) {                             // Tocou a parede esquerda?
      vx = fabsf(vx);                          // Força vx positivo (vai para a direita)
      bx = 1;                                  // Recoloca a bolinha dentro da tela
      beep(600, 15);                           // Som curto de rebote
    }
    if (bx >= SCREEN_W - 4) {                  // Tocou a parede direita?
      vx = -fabsf(vx);                         // Força vx negativo (vai para a esquerda)
      bx = SCREEN_W - 4;                       // Recoloca a bolinha dentro da tela
      beep(600, 15);                           // Som de rebote
    }
    if (by <= 1) {                             // Tocou o teto?
      vy = fabsf(vy);                          // Força vy positivo (passa a descer)
      by = 1;                                  // Recoloca a bolinha dentro da tela
      beep(600, 15);                           // Som de rebote
    }

    // Rebote na raquete: bolinha descendo, na altura da raquete e alinhada com ela na horizontal
    if (vy > 0 && by + 3 >= padY && by + 3 <= padY + BRK_PADH + 2 &&
        bx + 2 >= padX && bx <= padX + BRK_PADW) {
      vy = -fabsf(vy);                         // Inverte para subir
      // "rel" vai de -1 (ponta esquerda da raquete) a +1 (ponta direita), 0 = centro
      float rel = ((bx + 1) - (padX + BRK_PADW / 2.0f)) / (BRK_PADW / 2.0f);
      vx = rel * 3.0f;                         // O ângulo muda conforme onde a bolinha bateu
      if (fabsf(vx) < 0.5f)                    // Se ficou quase vertical...
        vx = (vx >= 0) ? 0.5f : -0.5f;         // ...garante pelo menos 0,5 de velocidade lateral
      by = padY - 3; // Push further away      // Afasta a bolinha da raquete para não bater de novo
      beep(900, 20);                           // Som de rebote na raquete
    }

    // Bolinha caiu abaixo da tela
    if (by > SCREEN_H + 2) {
      lives--;                                 // Perde uma vida
      beep(200, 300);                          // Som grave e longo
      if (lives <= 0) {                        // Acabaram as vidas?
        gameOver(score);                       // Mostra Game Over com a pontuação
        return;                                // Encerra o jogo e volta ao menu
      }
      bx = 64;                                 // Reposiciona a bolinha no centro...
      by = 45;
      vx = 1.8f;                               // ...com nova velocidade inicial
      vy = -2.2f;
      delay(600);                              // Pausa curta antes de continuar
    }

    // Colisão com os tijolos
    for (int r = 0; r < BRK_ROWS && bricksLeft > 0; r++) {   // Percorre as linhas
      for (int c = 0; c < BRK_COLS; c++) {                   // Percorre as colunas
        if (!bricks[r][c])                     // Se o tijolo já foi quebrado...
          continue;                            // ...pula
        int bkx = c * (BRK_BW + 1) + 1;        // Posição X do tijolo (largura + 1 px de espaço)
        int bky = r * (BRK_BH + 1) + 1;        // Posição Y do tijolo
        // A bolinha encosta no tijolo se os retângulos se sobrepõem
        if (bx + 3 >= bkx && bx <= bkx + BRK_BW && by + 3 >= bky &&
            by <= bky + BRK_BH) {
          bricks[r][c] = 0;                    // Quebra o tijolo
          bricksLeft--;                        // Um tijolo a menos
          score += (BRK_ROWS - r) * 10;        // Pontos: linhas de cima valem mais (40, 30, 20, 10)
          // Mede o quanto a bolinha "entrou" no tijolo por cada lado
          float overlapL = bx + 3 - bkx, overlapR = bkx + BRK_BW - bx,
                overlapT = by + 3 - bky, overlapB = bky + BRK_BH - by;
          float minH = min(overlapL, overlapR), minV = min(overlapT, overlapB);
          if (minH < minV)                     // Se entrou menos na horizontal...
            vx = -vx;                          // ...bateu na lateral: inverte X
          else                                 // Senão...
            vy = -vy;                          // ...bateu em cima/embaixo: inverte Y
          beep(1200 + r * 120, 25);            // Som mais agudo conforme a linha
          goto brick_done;                     // Sai dos dois loops (só 1 tijolo por frame)
        }
      }
    }
  brick_done:                                  // Ponto de destino do goto
    // Vitória: não sobrou nenhum tijolo
    if (bricksLeft == 0) {
      u8g2.clearBuffer();                      // Limpa a tela
      u8g2.setFont(u8g2_font_ncenB10_tr);      // Fonte grande
      centreStr("YOU WIN!", 28);               // Mensagem de vitória
      u8g2.setFont(u8g2_font_6x10_tr);         // Fonte pequena
      char buf[20];                            // Texto para a pontuação
      snprintf(buf, sizeof(buf), "Score: %u", score); // Monta "Score: N"
      centreStr(buf, 44);                      // Mostra a pontuação
      centreStr("Press any button", 58);       // Instrução
      u8g2.sendBuffer();                       // Envia para o display
      beep(1760, 100);                         // Pequena melodia de vitória
      delay(110);
      beep(1760, 100);
      delay(110);
      beep(2093, 300);
      delay(400);
      waitRelease();                           // Espera soltar os botões
      // Espera o jogador apertar qualquer botão
      while (!btnHeld(BTN_UP) && !btnHeld(BTN_DOWN) && !btnHeld(BTN_LEFT) &&
             !btnHeld(BTN_RIGHT))
        delay(15);
      waitRelease();                           // Espera soltar antes de voltar ao menu
      return;                                  // Encerra o jogo
    }

    // ── Desenho do frame ──
    u8g2.clearBuffer();                        // Limpa o buffer
    for (int r = 0; r < BRK_ROWS; r++) {       // Para cada linha de tijolos...
      for (int c = 0; c < BRK_COLS; c++) {     // ...e cada coluna...
        if (!bricks[r][c])                     // ...se o tijolo foi quebrado,
          continue;                            // ...não desenha
        int bkx = c * (BRK_BW + 1) + 1, bky = r * (BRK_BH + 1) + 1; // Posição do tijolo
        if (r % 2 == 0)                        // Linhas pares (0, 2)...
          u8g2.drawBox(bkx, bky, BRK_BW, BRK_BH);    // ...tijolo preenchido
        else                                   // Linhas ímpares (1, 3)...
          u8g2.drawFrame(bkx, bky, BRK_BW, BRK_BH);  // ...apenas o contorno
      }
    }
    u8g2.drawRBox(padX, padY, BRK_PADW, BRK_PADH, 1); // Raquete (caixa com cantos arredondados)
    u8g2.drawDisc((int)bx + 1, (int)by + 1, 2);       // Bolinha (círculo preenchido de raio 2)
    u8g2.setFont(u8g2_font_5x7_tr);            // Fonte bem pequena para o placar
    char sc[8];                                // Texto do placar
    itoa(score, sc, 10);                       // Converte o número em texto (base 10)
    u8g2.drawStr(1, 63, sc);                   // Escreve a pontuação no canto inferior esquerdo
    // Ícones de vidas no canto inferior direito
    for (int i = 0; i < lives; i++) {
      u8g2.drawPixel(SCREEN_W - 4 - i * 6, 60);        // Pixel em cima (a "bolinha" do ícone)
      u8g2.drawBox(SCREEN_W - 6 - i * 6, 61, 5, 3);    // Pequena barra embaixo (a "raquete" do ícone)
    }
    u8g2.sendBuffer();                         // Envia o quadro pronto ao display

    // Controle de velocidade: tenta manter ~50 frames por segundo (20 ms por frame)
    int32_t wait = 20 - (int32_t)(millis() - now); // Quanto falta para completar 20 ms
    if (wait > 0)                              // Se o frame foi mais rápido que isso...
      delay(wait);                             // ...espera o restante
  }
}

#endif                       // Fim da guarda de inclusão
