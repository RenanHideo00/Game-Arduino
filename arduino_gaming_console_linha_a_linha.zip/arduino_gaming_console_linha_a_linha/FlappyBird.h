#ifndef FLAPPYBIRD_H         // Guarda de inclusão: só compila se FLAPPYBIRD_H ainda não foi definido
#define FLAPPYBIRD_H         // Define FLAPPYBIRD_H para o arquivo não ser incluído duas vezes

#include <Arduino.h>         // Funções básicas do Arduino (millis, delay, random, itoa...)
#include <U8g2lib.h>         // Biblioteca gráfica do display OLED

// As linhas "extern" avisam que estas coisas já existem no arquivo principal (.ino)
extern U8G2_SSD1306_128X64_NONAME_F_HW_I2C u8g2;     // O objeto do display
extern bool btnPressed(uint8_t pin);                 // Detecta o instante em que um botão é apertado
extern bool btnHeld(uint8_t pin);                    // Detecta se um botão está sendo segurado
extern void beep(uint16_t freq, uint16_t ms);        // Toca um som no buzzer
extern void waitRelease();                           // Espera soltar todos os botões
extern void centreStr(const char *s, uint8_t y);     // Escreve texto centralizado
extern void gameOver(uint16_t score);                // Tela de Game Over com a pontuação

// Função principal do jogo; é chamada pelo menu e retorna quando o jogador perde
void game_flappy() {
  const float GRAVITY = 0.30f;     // Gravidade: aumenta a velocidade para baixo a cada frame
  const float FLAP_VEL = -2.20f;   // Velocidade do impulso ao bater as asas (negativo = para cima)
  const int GAP = 18;              // Altura da abertura entre o cano de cima e o de baixo
  const int PIPE_W = 8;            // Largura dos canos
  const int BIRD_X = 14;           // Posição X fixa do pássaro
  const int BIRD_W = 7;            // Largura do pássaro
  const int BIRD_H = 5;            // Altura do pássaro

  float birdY = 30, vel = 0;       // Posição Y do pássaro e sua velocidade vertical
  int pX[2] = {128, 192};          // Posição X de 2 canos (o segundo começa 64 px depois do primeiro)
  int pGap[2] = {20, 35};          // Y onde começa a abertura de cada cano (altura do cano de cima)
  int score = 0;                   // Pontuação: canos ultrapassados
  bool scored[2] = {false, false}; // Marca se cada cano já deu ponto (evita contar duas vezes)
  uint32_t lastFrame = 0;          // Momento do último frame (definido quando o jogo começa)

  // Instructions
  u8g2.clearBuffer();                          // Limpa o buffer da tela
  u8g2.setFont(u8g2_font_ncenB10_tr);          // Fonte grande para o título
  centreStr("FLAPPY BIRD", 24);                // Título centralizado
  u8g2.setFont(u8g2_font_6x10_tr);             // Fonte pequena para as instruções
  centreStr("ANY btn = Flap", 40);             // Qualquer botão bate as asas
  centreStr("Press ANY to start", 54);         // Pede para apertar um botão para começar
  u8g2.sendBuffer();                           // Envia o buffer para o display
  waitRelease();                               // Espera soltar qualquer botão que esteja apertado
  // Fica preso aqui até algum botão ser apertado (novo aperto)
  while (!btnPressed(BTN_UP) && !btnPressed(BTN_DOWN) &&
         !btnPressed(BTN_LEFT) && !btnPressed(BTN_RIGHT))
    delay(10);                                 // Espera 10 ms e verifica de novo
  vel = FLAP_VEL;                              // O primeiro aperto já dá o primeiro impulso
  beep(900, 35);                               // Som do primeiro bater de asas
  lastFrame = millis();                        // Começa a contar o tempo dos frames a partir de agora

  // ── Loop principal do jogo (1 volta = 1 frame) ──
  while (true) {
    uint32_t now = millis();                   // Hora atual em ms
    float dt = (now - lastFrame) / 30.0f;      // Fator de tempo desde o último frame (≈1.0 a 30 ms)
    if (dt > 3.0f)                             // Limita o dt para o jogo não "dar um salto"
      dt = 3.0f;
    lastFrame = now;                           // Guarda a hora deste frame

    // Flap
    // Flap (Any button)
    // Verdadeiro se QUALQUER um dos 4 botões acabou de ser apertado
    bool anyBtn = btnPressed(BTN_UP) || btnPressed(BTN_DOWN) ||
                  btnPressed(BTN_LEFT) || btnPressed(BTN_RIGHT);
    if (anyBtn) {                              // Se apertou algum botão...
      vel = FLAP_VEL;                          // ...o pássaro ganha impulso para cima
      beep(900, 30);                           // ...e toca um som curto
    }

    vel += GRAVITY * dt;                       // A gravidade puxa o pássaro para baixo
    birdY += vel * dt;                         // Atualiza a posição vertical com a velocidade

    // Move pipes
    for (int i = 0; i < 2; i++) {              // Para cada um dos 2 canos...
      pX[i] -= (int)(2.8f * dt);               // ...move para a esquerda (≈2,8 px por frame)
      if (pX[i] < -PIPE_W) {                   // Se saiu totalmente pela esquerda...
        pX[i] = SCREEN_W + random(10, 40);     // ...reaparece à direita, com distância aleatória
        pGap[i] = random(8, SCREEN_H - GAP - 8); // ...com a abertura em altura aleatória (entre 8 e 37)
        scored[i] = false;                     // ...e volta a poder dar ponto
      }
      if (!scored[i] && pX[i] + PIPE_W < BIRD_X) { // Se o cano passou totalmente pelo pássaro (e ainda não pontuou)...
        score++;                               // ...ganha 1 ponto
        scored[i] = true;                      // ...marca que este cano já pontuou
        beep(1300, 25);                        // ...e toca um som de ponto
      }
    }

    int by = (int)birdY;                       // Posição Y do pássaro em pixels inteiros

    // Ceiling / floor collision
    if (by < 0 || by + BIRD_H >= SCREEN_H) {   // Bateu no teto ou no chão?
      gameOver(score);                         // Mostra Game Over com a pontuação
      return;                                  // Encerra o jogo e volta ao menu
    }

    // Pipe collision
    for (int i = 0; i < 2; i++) {              // Para cada cano...
      if (BIRD_X + BIRD_W > pX[i] && BIRD_X < pX[i] + PIPE_W) {  // ...se o pássaro está na mesma coluna do cano...
        if (by < pGap[i] || by + BIRD_H > pGap[i] + GAP) {       // ...e está acima ou abaixo da abertura (bateu no cano)
          gameOver(score);                     // Mostra Game Over
          return;                              // Encerra o jogo
        }
      }
    }

    // ── Draw ──
    u8g2.clearBuffer();                        // Limpa o buffer para desenhar o novo quadro

    for (int i = 0; i < 2; i++) {              // Desenha cada cano
      u8g2.drawBox(pX[i], 0, PIPE_W, pGap[i]);                          // Cano de cima: do topo até o início da abertura
      u8g2.drawBox(pX[i] - 1, pGap[i] - 4, PIPE_W + 2, 5);              // "Boca" do cano de cima (mais larga)
      u8g2.drawBox(pX[i], pGap[i] + GAP, PIPE_W, SCREEN_H - (pGap[i] + GAP)); // Cano de baixo: do fim da abertura até a base
      u8g2.drawBox(pX[i] - 1, pGap[i] + GAP - 1, PIPE_W + 2, 5);        // "Boca" do cano de baixo
    }

    u8g2.drawBox(BIRD_X, by, BIRD_W, BIRD_H);  // Corpo do pássaro (retângulo preenchido)
    u8g2.setDrawColor(0);                      // Cor 0 = apagar pixels
    u8g2.drawPixel(BIRD_X + 5, by + 1);        // Olho (pixel apagado dentro do corpo)
    u8g2.setDrawColor(1);                      // Volta à cor normal (pixel aceso)
    u8g2.drawPixel(BIRD_X + 7, by + 2);        // Bico (pixel logo à direita do corpo)

    u8g2.setFont(u8g2_font_6x10_tr);           // Fonte do placar
    char sc[6];                                // Texto onde o número será guardado
    itoa(score, sc, 10);                       // Converte a pontuação em texto (base 10)
    u8g2.drawStr(2, 10, sc);                   // Escreve no canto superior esquerdo

    u8g2.sendBuffer();                         // Envia o quadro pronto ao display

    // Controle de velocidade: tenta manter ~30 frames por segundo (33 ms por frame)
    int32_t wait = 33 - (int32_t)(millis() - now);   // Quanto falta para completar 33 ms
    if (wait > 0)                              // Se o frame foi mais rápido que isso...
      delay(wait);                             // ...espera o restante
  }
}

#endif                       // Fim da guarda de inclusão
