#ifndef SPACEINVADERS_H      // Guarda de inclusão: só compila se SPACEINVADERS_H ainda não foi definido
#define SPACEINVADERS_H      // Define SPACEINVADERS_H para o arquivo não ser incluído duas vezes

#include <Arduino.h>         // Funções básicas do Arduino (millis, delay, random, itoa...)
#include <U8g2lib.h>         // Biblioteca gráfica do display OLED

// As linhas "extern" avisam que estas coisas já existem no arquivo principal (.ino)
extern U8G2_SSD1306_128X64_NONAME_F_HW_I2C u8g2;     // O objeto do display
extern bool btnPressed(uint8_t pin);                 // Detecta o instante em que um botão é apertado
extern bool btnHeld(uint8_t pin);                    // Detecta se um botão está sendo segurado
extern void beep(uint16_t freq, uint16_t ms);        // Toca um som no buzzer
extern void waitRelease();                           // Espera soltar todos os botões
extern void centreStr(const char *s, uint8_t y);     // Escreve texto centralizado
extern void gameOver(uint16_t score);                // Tela de Game Over com a pontuação

#define INV_COLS 8           // Número de colunas de invasores
#define INV_ROWS 3           // Número de linhas de invasores
#define INV_W 7              // Largura de cada invasor (pixels)
#define INV_H 5              // Altura de cada invasor (pixels)
#define INV_BULLETS 3        // Máximo de tiros na tela ao mesmo tempo (para cada lado)

// Estrutura que representa um tiro
struct Bullet {
  float x, y;                // Posição do tiro
  bool on;                   // true = tiro ativo (existe); false = vaga livre
};

// Função principal do jogo; é chamada pelo menu e retorna quando o jogador perde
void game_spaceinvaders() {
  bool inv[INV_ROWS][INV_COLS];            // Matriz dos invasores: true = vivo, false = destruído
  for (int r = 0; r < INV_ROWS; r++)       // Percorre cada linha...
    for (int c = 0; c < INV_COLS; c++)     // ...e cada coluna...
      inv[r][c] = true;                    // ...e coloca um invasor vivo
  int invLeft = INV_ROWS * INV_COLS;       // Quantos invasores ainda estão vivos (começa com 24)
  int gridX = 4, gridY = 4;                // Posição do canto superior esquerdo do grupo de invasores
  int8_t gridDX = 1;                       // Direção horizontal do grupo: 1 = direita, -1 = esquerda
  uint32_t lastInvMove = 0;                // Momento do último movimento do grupo
  uint16_t invSpeed = 500;                 // Intervalo (ms) entre movimentos do grupo: menor = mais rápido
  int shipX = SCREEN_W / 2 - 4;            // Posição X da nave do jogador: começa no meio
  const int shipY = SCREEN_H - 10;         // Posição Y da nave: fixa, perto da base
  Bullet pb[INV_BULLETS], eb[INV_BULLETS]; // pb = tiros do jogador; eb = tiros dos inimigos
  for (auto &b : pb)                       // Marca todos os tiros do jogador como inativos
    b.on = false;
  for (auto &b : eb)                       // Marca todos os tiros inimigos como inativos
    b.on = false;
  uint32_t lastShoot = 0, lastEnemyShoot = 0;  // Momento do último tiro do jogador e do último tiro inimigo
  uint16_t score = 0;                      // Pontuação
  uint8_t wave = 1;                        // Número da onda atual
  uint32_t lastFrame = millis();           // Momento do último frame (para calcular dt)
  bool animFrame = false;                  // Alterna entre dois quadros de animação dos invasores

  // ── Tela de instruções ──
  u8g2.clearBuffer();                      // Limpa o buffer da tela
  u8g2.setFont(u8g2_font_ncenB10_tr);      // Fonte grande para o título
  centreStr("INVADERS", 24);               // Título centralizado
  u8g2.setFont(u8g2_font_6x10_tr);         // Fonte pequena para as instruções
  centreStr("L/R = Move (Auto-fire)", 40); // Esquerda/direita move; o tiro é automático
  centreStr("Destroy them all!", 54);      // Objetivo
  u8g2.sendBuffer();                       // Envia o buffer para o display
  delay(1500);                             // Deixa o jogador ler por 1,5 segundo
  waitRelease();                           // Garante que nenhum botão esteja apertado ao começar

  // ── Loop principal do jogo (1 volta = 1 frame) ──
  while (true) {
    uint32_t now = millis();               // Hora atual em ms
    float dt = (now - lastFrame) / 20.0f;  // Fator de tempo desde o último frame (≈1.0 a 20 ms)
    lastFrame = now;                       // Guarda a hora deste frame
    animFrame = (now / 300) % 2;           // Troca o quadro de animação a cada 300 ms

    // Movimento da nave do jogador
    if (btnHeld(BTN_LEFT))                 // Se ESQUERDA está segurado...
      shipX = max(0, shipX - 3);           // ...move 3 px para a esquerda, sem sair da tela
    if (btnHeld(BTN_RIGHT))                // Se DIREITA está segurado...
      shipX = min(SCREEN_W - 10, shipX + 3); // ...move 3 px para a direita (a nave tem 10 px de largura)

    // Autofire
    // Tiro automático do jogador: a cada 450 ms
    if (now - lastShoot > 450) {
      for (auto &b : pb)                   // Procura uma vaga livre entre os tiros do jogador
        if (!b.on) {
          b.x = shipX + 4;                 // O tiro sai do centro da nave
          b.y = shipY - 1;                 // ...logo acima dela
          b.on = true;                     // Ativa o tiro
          beep(1500, 15);                  // Som de tiro
          break;                           // Cria só um tiro por vez
        }
      lastShoot = now;                     // Anota o momento do disparo
    }

    // Movimento dos tiros do jogador e colisão com invasores
    for (auto &b : pb) {
      if (!b.on)                           // Tiro inativo: pula
        continue;
      b.y -= 4.0f * dt;                    // Sobe 4 px por frame
      if (b.y < 0) {                       // Saiu pelo topo da tela?
        b.on = false;                      // Desativa o tiro
        continue;
      }
      // Descobre em qual coluna (bc) e linha (br) do grupo de invasores o tiro está.
      // Cada invasor ocupa uma célula de (INV_W + 2) x (INV_H + 3) pixels.
      int bc = (int(b.x) - gridX) / (INV_W + 2),
          br = (int(b.y) - gridY) / (INV_H + 3);
      // Se a célula existe e o invasor dela está vivo...
      if (bc >= 0 && bc < INV_COLS && br >= 0 && br < INV_ROWS && inv[br][bc]) {
        int ix = gridX + bc * (INV_W + 2), iy = gridY + br * (INV_H + 3); // Posição do invasor em pixels
        // ...confere se o tiro realmente está dentro do desenho do invasor
        if (b.x >= ix && b.x <= ix + INV_W && b.y >= iy && b.y <= iy + INV_H) {
          inv[br][bc] = false;             // Destrói o invasor
          invLeft--;                       // Um invasor a menos
          score += (INV_ROWS - br) * 10;   // Pontos: linhas de cima valem mais (30, 20, 10)
          b.on = false;                    // O tiro some
          beep(800 - br * 100, 40);        // Som de explosão (mais grave nas linhas de baixo)
        }
      }
    }

    // Tiro dos inimigos: o intervalo diminui conforme a pontuação, com mínimo de 400 ms
    if (invLeft > 0 && now - lastEnemyShoot > max(400U, 1200U - score * 2)) {
      lastEnemyShoot = now;                // Anota o momento do disparo
      int tries = 20;                      // Até 20 tentativas de achar uma coluna com invasor vivo
      while (tries--) {
        int c = random(0, INV_COLS);       // Sorteia uma coluna
        for (int r = INV_ROWS - 1; r >= 0; r--) {   // Procura de baixo para cima...
          if (inv[r][c]) {                 // ...o invasor vivo mais baixo desta coluna
            for (auto &b : eb)             // Procura uma vaga livre entre os tiros inimigos
              if (!b.on) {
                b.x = gridX + c * (INV_W + 2) + INV_W / 2;  // O tiro sai do centro do invasor
                b.y = gridY + r * (INV_H + 3) + INV_H;      // ...pela parte de baixo dele
                b.on = true;               // Ativa o tiro
                break;
              }
            goto shot_done;                // Já atirou (ou não havia vaga): sai dos laços
          }
        }
      }
    shot_done:;                            // Destino do goto
    }

    // Movimento dos tiros inimigos e colisão com a nave
    for (auto &b : eb) {
      if (!b.on)                           // Tiro inativo: pula
        continue;
      b.y += 3.0f * dt;                    // Desce 3 px por frame
      if (b.y > SCREEN_H) {                // Saiu pela base da tela?
        b.on = false;                      // Desativa o tiro
        continue;
      }
      // Se o tiro está dentro da área da nave (10 px de largura e 7 de altura)...
      if (b.x >= shipX && b.x <= shipX + 10 && b.y >= shipY &&
          b.y <= shipY + 7) {
        gameOver(score);                   // ...a nave foi atingida: mostra Game Over
        return;                            // Encerra o jogo e volta ao menu
      }
    }

    // Movimento do grupo de invasores (só acontece a cada "invSpeed" ms)
    if (now - lastInvMove > invSpeed) {
      lastInvMove = now;                   // Anota o momento do movimento
      gridX += gridDX;                     // Move o grupo 1 px na direção atual
      // Descobre as colunas mais à esquerda e mais à direita que ainda têm invasores vivos
      int leftC = INV_COLS, rightC = -1;
      for (int r = 0; r < INV_ROWS; r++)
        for (int c = 0; c < INV_COLS; c++)
          if (inv[r][c]) {
            leftC = min(leftC, c);
            rightC = max(rightC, c);
          }
      // Se a borda direita ou esquerda do grupo encostou na parede da tela...
      if (gridX + rightC * (INV_W + 2) + INV_W >= SCREEN_W - 2 ||
          gridX + leftC * (INV_W + 2) <= 2) {
        gridDX = -gridDX;                  // ...inverte a direção horizontal
        gridY += 3;                        // ...e desce 3 px
      }
      // Se o grupo chegou perto da nave, o jogador perde
      if (gridY + INV_ROWS * (INV_H + 3) >= shipY - 2) {
        gameOver(score);
        return;
      }
    }

    // Nova onda: todos os invasores foram destruídos
    if (invLeft == 0) {
      wave++;                              // Próxima onda
      invSpeed = (uint16_t)max(80, (int)invSpeed - 60);   // Grupo fica mais rápido (mínimo de 80 ms)
      for (int r = 0; r < INV_ROWS; r++)   // Recria todos os invasores
        for (int c = 0; c < INV_COLS; c++)
          inv[r][c] = true;
      invLeft = INV_ROWS * INV_COLS;       // Volta a ter 24 invasores
      gridX = 4;                           // Reposiciona o grupo no canto superior esquerdo
      gridY = 4;
      gridDX = 1;                          // ...indo para a direita
      beep(1760, 100);                     // Pequena melodia de nova onda
      delay(110);
      beep(2093, 200);
      delay(400);
    }

    // ── Desenho do frame ──
    u8g2.clearBuffer();                    // Limpa o buffer para desenhar o novo quadro

    // Desenha os invasores: cada linha tem um desenho diferente, com 2 quadros de animação
    for (int r = 0; r < INV_ROWS; r++) {
      for (int c = 0; c < INV_COLS; c++) {
        if (!inv[r][c])                    // Invasor destruído: não desenha
          continue;
        int ix = gridX + c * (INV_W + 2), iy = gridY + r * (INV_H + 3);  // Posição do invasor em pixels
        if (r == 0) {                      // Linha de cima
          u8g2.drawBox(ix + 1, iy, 5, 2);          // Cabeça
          u8g2.drawBox(ix, iy + 2, 7, 2);          // Corpo
          if (animFrame) {                         // Quadro 1: pernas abertas
            u8g2.drawPixel(ix, iy + 4);
            u8g2.drawPixel(ix + 6, iy + 4);
          } else {                                 // Quadro 2: pernas fechadas
            u8g2.drawPixel(ix + 1, iy + 4);
            u8g2.drawPixel(ix + 5, iy + 4);
          }
        } else if (r == 1) {               // Linha do meio
          u8g2.drawBox(ix + 1, iy + 1, 5, 3);      // Corpo
          u8g2.drawPixel(ix + 1, iy);              // "Antenas"
          u8g2.drawPixel(ix + 5, iy);
          if (animFrame) {                         // Quadro 1: braços levantados
            u8g2.drawPixel(ix, iy + 2);
            u8g2.drawPixel(ix + 6, iy + 2);
          } else {                                 // Quadro 2: braços abaixados
            u8g2.drawPixel(ix, iy + 3);
            u8g2.drawPixel(ix + 6, iy + 3);
          }
        } else {                           // Linha de baixo
          u8g2.drawBox(ix + 2, iy, 3, 4);          // Corpo
          u8g2.drawPixel(ix + 1, iy + 1);          // Laterais
          u8g2.drawPixel(ix + 5, iy + 1);
          if (animFrame) {                         // Quadro 1: três pés
            u8g2.drawPixel(ix, iy + 4);
            u8g2.drawPixel(ix + 3, iy + 4);
            u8g2.drawPixel(ix + 6, iy + 4);
          } else {                                 // Quadro 2: dois pés
            u8g2.drawPixel(ix + 1, iy + 4);
            u8g2.drawPixel(ix + 5, iy + 4);
          }
        }
      }
    }

    // Nave do jogador: três retângulos empilhados, formando uma pirâmide
    u8g2.drawBox(shipX + 3, shipY, 4, 2);          // Topo (estreito)
    u8g2.drawBox(shipX + 1, shipY + 2, 8, 3);      // Meio
    u8g2.drawBox(shipX, shipY + 4, 10, 3);         // Base (larga)

    for (auto &b : pb)                             // Tiros do jogador: linha vertical de 4 px
      if (b.on)
        u8g2.drawBox((int)b.x, (int)b.y, 1, 4);
    for (auto &b : eb)                             // Tiros inimigos: dois pontinhos com espaço no meio
      if (b.on) {
        u8g2.drawPixel((int)b.x, (int)b.y);
        u8g2.drawPixel((int)b.x, (int)b.y + 2);
      }

    u8g2.drawHLine(0, SCREEN_H - 1, SCREEN_W);     // Linha do chão, na última linha da tela
    u8g2.setFont(u8g2_font_5x7_tr);                // Fonte bem pequena para o placar
    char sc[8];                                    // Texto da pontuação
    itoa(score, sc, 10);                           // Converte a pontuação em texto
    u8g2.drawStr(1, 8, sc);                        // Pontuação no canto superior esquerdo
    char wv[8];                                    // Texto da onda
    snprintf(wv, sizeof(wv), "W%u", wave);         // Monta "W1", "W2"...
    u8g2.drawStr(SCREEN_W - 18, 8, wv);            // Onda no canto superior direito
    u8g2.sendBuffer();                             // Envia o quadro pronto ao display

    // Controle de velocidade: tenta manter ~50 frames por segundo (20 ms por frame)
    int32_t wait = 20 - (int32_t)(millis() - now); // Quanto falta para completar 20 ms
    if (wait > 0)                                  // Se o frame foi mais rápido que isso...
      delay(wait);                                 // ...espera o restante
  }
}

#endif                       // Fim da guarda de inclusão
