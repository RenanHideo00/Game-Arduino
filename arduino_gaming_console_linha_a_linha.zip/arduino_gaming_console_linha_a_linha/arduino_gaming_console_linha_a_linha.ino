/*
 ============================================================
                ARDUINO GAMING CONSOLE 
 ============================================================
   Hardware:
     - Arduino UNO R4 (Minima or WiFi)
     - 128x64 I2C OLED (SSD1306)   SDA=A4, SCL=A5
     - Buzzer                       Pin 7
     - BTN_UP                       Pin 4
     - BTN_DOWN                     Pin 2
     - BTN_LEFT                     Pin 3
     - BTN_RIGHT (Flap / Select)    Pin 5
 ============================================================
*/

#include <Arduino.h>   // Funções básicas do Arduino (pinMode, digitalRead, delay, tone...)
#include <U8g2lib.h>   // Biblioteca gráfica U8g2: desenha texto e formas no display OLED
#include <Wire.h>      // Biblioteca I2C: protocolo de comunicação usado pelo display

// ── Display ────────────────────────────────────────────────
// Cria o objeto "u8g2" que controla o display:
//  - SSD1306: chip controlador do OLED
//  - 128X64: resolução em pixels
//  - F: modo "full buffer" (desenha tudo na RAM e envia de uma vez)
//  - HW_I2C: usa o hardware I2C do Arduino (pinos A4/A5)
//  - U8G2_R0: sem rotação da imagem
//  - U8X8_PIN_NONE: o display não tem pino de reset ligado
U8G2_SSD1306_128X64_NONAME_F_HW_I2C u8g2(U8G2_R0, /* reset=*/U8X8_PIN_NONE);

#define SCREEN_W 128   // Largura da tela em pixels
#define SCREEN_H 64    // Altura da tela em pixels

// ── Buttons ────────────────────────────────────────────────
#define BTN_UP 4       // Botão CIMA está no pino digital 4
#define BTN_DOWN 2     // Botão BAIXO está no pino digital 2
#define BTN_LEFT 3     // Botão ESQUERDA está no pino digital 3
#define BTN_RIGHT 5    // Botão DIREITA (também usado como "pular"/"confirmar") no pino 5

// ── Buzzer ─────────────────────────────────────────────────
#define BUZZER_PIN 7   // Buzzer está no pino digital 7

// ═══════════════════════════════════════════════════════════
//  UTILITY HELPERS
// ═══════════════════════════════════════════════════════════

// Retorna true UMA vez no instante em que o botão é apertado (com debounce)
bool btnPressed(uint8_t pin) {
  // Guarda, para cada um dos 4 botões, o instante da última mudança de estado.
  // "static" faz o valor ser mantido entre uma chamada e outra da função.
  static uint32_t lastTime[4] = {0, 0, 0, 0};
  // Guarda o último estado lido de cada botão (true = pressionado)
  static bool lastSt[4] = {true, true, true, true};
  uint8_t idx;               // Índice (0 a 3) do botão nos arrays acima
  if (pin == BTN_UP)         // Se for o botão CIMA...
    idx = 0;                 // ...usa a posição 0
  else if (pin == BTN_DOWN)  // Se for o botão BAIXO...
    idx = 1;                 // ...usa a posição 1
  else if (pin == BTN_LEFT)  // Se for o botão ESQUERDA...
    idx = 2;                 // ...usa a posição 2
  else if (pin == BTN_RIGHT) // Se for o botão DIREITA...
    idx = 3;                 // ...usa a posição 3
  else                       // Se for qualquer outro pino...
    return false;            // ...não é um botão conhecido, retorna "não apertado"

  // Lê o pino: com INPUT_PULLUP, botão apertado = LOW. Então cur = true se apertado.
  bool cur = (digitalRead(pin) == LOW);
  // É um "aperto novo" se: está apertado agora, NÃO estava antes,
  // e passaram mais de 40 ms desde a última mudança (filtra o ruído/repique)
  bool edge = cur && !lastSt[idx] && (millis() - lastTime[idx] > 40);
  if (cur != lastSt[idx])      // Se o estado mudou desde a última leitura...
    lastTime[idx] = millis();  // ...anota o momento da mudança (para o debounce)
  lastSt[idx] = cur;           // Salva o estado atual para a próxima chamada
  return edge;                 // Devolve true só no instante do aperto
}

// Retorna true enquanto o botão estiver sendo segurado (apertado = LOW)
bool btnHeld(uint8_t pin) { return digitalRead(pin) == LOW; }

// Toca uma nota no buzzer: "freq" em Hz, "ms" de duração em milissegundos.
// tone() não trava o programa; o som toca em segundo plano.
void beep(uint16_t freq, uint16_t ms) { tone(BUZZER_PIN, freq, ms); }

// Espera o jogador soltar todos os botões
void waitRelease() {
  delay(30);                 // Pequena pausa para estabilizar a leitura
  // Enquanto QUALQUER botão ainda estiver apertado...
  while (btnHeld(BTN_UP) || btnHeld(BTN_DOWN) || btnHeld(BTN_LEFT) ||
         btnHeld(BTN_RIGHT))
    delay(10);               // ...espera 10 ms e verifica de novo
}

// Escreve um texto centralizado na horizontal, na altura "y"
void centreStr(const char *s, uint8_t y) {
  uint8_t w = u8g2.getStrWidth(s);          // Mede a largura do texto em pixels
  u8g2.drawStr((SCREEN_W - w) / 2, y, s);   // Posição x = (largura da tela - largura do texto) / 2
}

// ── Music Helpers ──
// Música de abertura. Cada nota: beep(frequência, duração) + delay(tempo até a próxima)
void playStartMusic() {
  // ~2.5 second Upbeat Jingle
  beep(523, 150);            // Toca a nota por 150 ms
  delay(200); // C5          // Espera 200 ms (nota + pequena pausa)
  beep(659, 150);            // Toca a próxima nota
  delay(200); // E5
  beep(784, 150);
  delay(200); // G5
  beep(523, 150);
  delay(200); // C5
  beep(784, 150);
  delay(200); // G5
  beep(1046, 300);           // Nota mais longa (300 ms)
  delay(400); // C6
  beep(880, 150);
  delay(200);      // A5
  beep(1046, 500); // C6     // Nota final, a mais longa (500 ms)
}

// Música de fim de jogo: notas descendentes (som "triste")
void playGameOverMusic() {
  // ~2.5 second Descending Theme
  beep(392, 250);            // Toca a nota por 250 ms
  delay(300); // G4          // Espera 300 ms antes da próxima
  beep(349, 250);
  delay(300); // F4
  beep(329, 250);
  delay(300); // E4
  beep(261, 500);
  delay(600);     // C4
  beep(196, 700); // G3      // Última nota, grave e longa
}

// ═══════════════════════════════════════════════════════════
//  GAME HEADERS
// ═══════════════════════════════════════════════════════════
// Cada #include abaixo traz um jogo completo (arquivo .h na mesma pasta).
// Ficam aqui, DEPOIS das funções utilitárias, porque os jogos usam
// u8g2, btnPressed, beep, gameOver, etc.
#include "Asteroids.h"        // Jogo Asteroids  -> game_asteroids()
#include "Breakout.h"         // Jogo Breakout   -> game_breakout()
#include "Dino.h"             // Jogo Dino Run   -> game_dino()
#include "FlappyBird.h"       // Jogo Flappy Bird -> game_flappy()
#include "MazeRunner.h"       // Jogo Maze Runner -> game_maze()
#include "Pacman.h"           // Jogo Pacman     -> game_pacman()
#include "Pong.h"             // Jogo Pong       -> game_pong()
#include "Snake.h"            // Jogo Snake      -> game_snake()
#include "SpaceInvaders.h"    // Jogo Space Invaders -> game_spaceinvaders()
#include "Tetris.h"           // Jogo Tetris     -> game_tetris()

// ═══════════════════════════════════════════════════════════
//  SPLASH + MENU
// ═══════════════════════════════════════════════════════════

// Tela de abertura
void showSplash() {
  u8g2.clearBuffer();                    // Apaga o buffer (a "tela" na memória)
  u8g2.setFont(u8g2_font_ncenB10_tr);    // Escolhe uma fonte grande e em negrito
  centreStr("GAME CONSOLE", 28);         // Escreve o título centralizado na linha y=28
  u8g2.setFont(u8g2_font_6x10_tr);       // Troca para uma fonte pequena (6x10 pixels)
  centreStr("Press any button...", 48);  // Escreve a instrução na linha y=48
  u8g2.sendBuffer();                     // Envia o buffer para o display (agora aparece)
  playStartMusic();                      // Toca a música de abertura
  // Fica preso aqui enquanto NENHUM botão estiver apertado
  while (!btnHeld(BTN_UP) && !btnHeld(BTN_DOWN) && !btnHeld(BTN_LEFT) &&
         !btnHeld(BTN_RIGHT))
    delay(15);                           // Espera 15 ms e verifica de novo
  waitRelease();                         // Espera soltar o botão antes de continuar
}

// Tela de "Game Over" que recebe a pontuação final
void gameOver(uint16_t score) {
  char buf[20];                                // Texto onde será montado "Score: N"
  snprintf(buf, sizeof(buf), "Score: %u", score); // Escreve a pontuação dentro de buf
  u8g2.clearBuffer();                          // Limpa o buffer
  u8g2.setFont(u8g2_font_ncenB10_tr);          // Fonte grande
  centreStr("GAME OVER", 28);                  // Título centralizado
  u8g2.setFont(u8g2_font_6x10_tr);             // Fonte pequena
  centreStr(buf, 44);                          // Mostra a pontuação
  centreStr("Press any button", 58);           // Mostra a instrução
  u8g2.sendBuffer();                           // Envia tudo para a tela
  playGameOverMusic();                         // Toca a música de derrota
  delay(400);                                  // Pausa curta
  waitRelease();                               // Espera soltar o botão que usava no jogo
  // Espera o jogador apertar qualquer botão para sair desta tela
  while (!btnHeld(BTN_UP) && !btnHeld(BTN_DOWN) && !btnHeld(BTN_LEFT) &&
         !btnHeld(BTN_RIGHT))
    delay(15);
  waitRelease();                               // Espera soltar antes de voltar ao menu
}

#define GAME_COUNT 10   // Número total de jogos no menu

// Mostra o menu e devolve o número (0 a 9) do jogo escolhido
int menuSelect() {
  // Lista com os nomes que aparecem no menu (na ordem dos jogos)
  const char *names[GAME_COUNT] = {
      "1. Asteroids",      "2. Breakout", "3. Dino Run", "4. Flappy Bird",
      "5. Maze Runner",    "6. Pacman",   "7. Pong",     "8. Snake",
      "9. Space Invaders", "10. Tetris"};
  int sel = 0;            // Item selecionado no momento (começa no primeiro)
  int top = 0;            // Primeiro item visível na tela (controla a rolagem)
  const int VISIBLE = 4;  // Quantos itens cabem na tela de uma vez

  while (true) {          // Loop do menu: repete até o jogador escolher
    if (sel < top)                  // Se o selecionado está acima da janela visível...
      top = sel;                    // ...rola a janela para cima
    if (sel >= top + VISIBLE)       // Se está abaixo da janela visível...
      top = sel - VISIBLE + 1;      // ...rola a janela para baixo

    u8g2.clearBuffer();                    // Limpa o buffer para redesenhar o menu
    u8g2.setFont(u8g2_font_6x10_tr);       // Fonte pequena do menu
    u8g2.drawBox(0, 0, SCREEN_W, 11);      // Faixa preenchida no topo (cabeçalho)
    u8g2.setDrawColor(0);                  // Cor 0 = "apagar" pixels (texto preto na faixa)
    centreStr("** GAME CONSOLE **", 9);    // Título do cabeçalho
    u8g2.setDrawColor(1);                  // Volta à cor normal (pixels acesos)

    // Desenha cada um dos itens visíveis
    for (int i = 0; i < VISIBLE; i++) {
      int idx = top + i;           // Índice real do jogo na lista
      if (idx >= GAME_COUNT)       // Se passou do último jogo...
        break;                     // ...para de desenhar
      int y = 13 + i * 13;         // Posição vertical: cada linha tem 13 pixels de altura
      if (idx == sel) {            // Se este é o item selecionado...
        u8g2.drawRBox(0, y, SCREEN_W - 10, 12, 2);  // ...desenha uma caixa preenchida com cantos arredondados
        u8g2.setDrawColor(0);                       // ...e escreve o texto em "preto" sobre ela
        u8g2.drawStr(4, y + 9, names[idx]);         // Texto 4 px da borda; y+9 é a linha de base
        u8g2.setDrawColor(1);                       // Volta à cor normal
      } else {                     // Se NÃO é o selecionado...
        u8g2.drawStr(4, y + 9, names[idx]);         // ...escreve só o texto normal
      }
    }

    // Barra de rolagem na lateral direita
    u8g2.drawFrame(SCREEN_W - 7, 12, 6, 52);  // Moldura (trilho) da barra
    int thumbH = max(6, 52 / GAME_COUNT * VISIBLE);  // Altura do marcador (mínimo de 6 px)
    int thumbY = 12 + (sel * (52 - thumbH)) / (GAME_COUNT - 1); // Posição do marcador conforme o item selecionado
    u8g2.drawBox(SCREEN_W - 6, thumbY, 4, thumbH);  // Desenha o marcador

    if (top > 0)                                // Se há itens escondidos acima...
      u8g2.drawStr(SCREEN_W - 8, 13, "^");      // ...mostra uma seta para cima
    if (top + VISIBLE < GAME_COUNT)             // Se há itens escondidos abaixo...
      u8g2.drawStr(SCREEN_W - 8, 62, "v");      // ...mostra uma seta para baixo

    u8g2.sendBuffer();      // Envia o menu desenhado para o display
    delay(100);             // Espera 100 ms (define a velocidade do menu)

    if (btnPressed(BTN_UP)) {                   // Apertou CIMA?
      sel = (sel + GAME_COUNT - 1) % GAME_COUNT; // Sobe um item; do primeiro volta ao último
      beep(800, 25);                            // Bip curto de navegação
    }
    if (btnPressed(BTN_DOWN)) {                 // Apertou BAIXO?
      sel = (sel + 1) % GAME_COUNT;             // Desce um item; do último volta ao primeiro
      beep(800, 25);                            // Bip curto de navegação
    }
    if (btnPressed(BTN_LEFT) || btnPressed(BTN_RIGHT)) { // Apertou ESQUERDA ou DIREITA (confirmar)?
      beep(1200, 60);                           // Bip de confirmação (mais agudo)
      waitRelease();                            // Espera soltar o botão
      return sel;                               // Devolve o jogo escolhido e sai do menu
    }
  }
}

// setup(): roda UMA vez quando o Arduino liga ou reinicia
void setup() {
  pinMode(BTN_UP, INPUT_PULLUP);     // Botão CIMA como entrada com resistor interno (solto=HIGH, apertado=LOW)
  pinMode(BTN_DOWN, INPUT_PULLUP);   // Botão BAIXO, mesma configuração
  pinMode(BTN_LEFT, INPUT_PULLUP);   // Botão ESQUERDA, mesma configuração
  pinMode(BTN_RIGHT, INPUT_PULLUP);  // Botão DIREITA, mesma configuração
  pinMode(BUZZER_PIN, OUTPUT);       // Pino do buzzer como saída
  randomSeed(analogRead(A0));        // Semente aleatória lida de um pino analógico solto (ruído), para random() variar a cada partida
  u8g2.begin();                      // Inicializa o display
  u8g2.setContrast(200);             // Ajusta o brilho/contraste (0 a 255)
  u8g2.setFont(u8g2_font_6x10_tr);   // Define a fonte padrão
  u8g2.setDrawColor(1);              // Cor de desenho padrão: pixel aceso
  u8g2.setBitmapMode(0);             // Imagens opacas (o fundo do bitmap também é desenhado)
  showSplash();                      // Mostra a tela de abertura
}

// loop(): repete para sempre depois do setup()
void loop() {
  int sel = menuSelect();   // Mostra o menu e espera o jogador escolher um jogo
  switch (sel) {            // Executa o jogo correspondente ao número escolhido
  case 0:
    game_asteroids();       // 0 -> Asteroids
    break;                  // Sai do switch
  case 1:
    game_breakout();        // 1 -> Breakout
    break;
  case 2:
    game_dino();            // 2 -> Dino Run
    break;
  case 3:
    game_flappy();          // 3 -> Flappy Bird
    break;
  case 4:
    game_maze();            // 4 -> Maze Runner
    break;
  case 5:
    game_pacman();          // 5 -> Pacman
    break;
  case 6:
    game_pong();            // 6 -> Pong
    break;
  case 7:
    game_snake();           // 7 -> Snake
    break;
  case 8:
    game_spaceinvaders();   // 8 -> Space Invaders
    break;
  case 9:
    game_tetris();          // 9 -> Tetris
    break;
  }
  // Quando o jogo termina, o loop() recomeça e mostra o menu de novo
}
