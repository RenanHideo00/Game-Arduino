#ifndef SNAKE_H              // Guarda de inclusão: só compila se SNAKE_H ainda não foi definido
#define SNAKE_H              // Define SNAKE_H para o arquivo não ser incluído duas vezes

#include <Arduino.h>         // Funções básicas do Arduino (millis, delay, random, itoa...)
#include <U8g2lib.h>         // Biblioteca gráfica do display OLED

// Snake constants
#define SN_COLS 21 // grid width  (each cell = 6 px)    // Número de colunas da grade
#define SN_ROWS 10 // grid height (each cell = 6 px)    // Número de linhas da grade
#define SN_SZ 6              // Tamanho de cada célula da grade, em pixels
#define SN_OFFX 1            // Deslocamento X da grade na tela (margem esquerda)
#define SN_OFFY 4            // Deslocamento Y da grade na tela (margem superior)
#define SN_MAXLEN 80         // Tamanho máximo da cobra (limite do vetor de posições)

// As linhas "extern" avisam que estas coisas já existem no arquivo principal (.ino)
extern U8G2_SSD1306_128X64_NONAME_F_HW_I2C u8g2;     // O objeto do display
extern bool btnPressed(uint8_t pin);                 // Detecta o instante em que um botão é apertado
extern bool btnHeld(uint8_t pin);                    // Detecta se um botão está sendo segurado
extern void beep(uint16_t freq, uint16_t ms);        // Toca um som no buzzer
extern void waitRelease();                           // Espera soltar todos os botões
extern void centreStr(const char *s, uint8_t y);     // Escreve texto centralizado
extern void gameOver(uint16_t score);                // Tela de Game Over com a pontuação

// Função principal do jogo; é chamada pelo menu e retorna quando a cobra bate em si mesma
void game_snake() {
  int sx[SN_MAXLEN], sy[SN_MAXLEN];  // Posições (coluna, linha) de cada segmento; índice 0 = cabeça
  int len = 4;                       // Tamanho inicial da cobra (4 segmentos)
  int dx = 1, dy = 0;                // Direção atual: começa indo para a direita
  int next_dx = 1, next_dy = 0; // Buffer for next direction   // Próxima direção (guardada até o próximo passo)
  int fx, fy;                        // Posição (coluna, linha) da comida
  uint32_t lastMove = 0;             // Momento do último passo da cobra
  uint16_t spd = 210; // ms per step // Tempo entre passos: quanto menor, mais rápida
  uint16_t score = 0;                // Pontuação: quantas comidas foram comidas

  // Place food avoiding snake body
  // Função (lambda) que sorteia uma posição para a comida; [&] permite usar as variáveis de fora
  auto placeFood = [&]() {
    bool ok;
    do {                                   // Repete até achar uma posição livre
      ok = true;                           // Supõe que a posição sorteada é válida
      fx = random(0, SN_COLS);             // Sorteia a coluna
      fy = random(0, SN_ROWS);             // Sorteia a linha
      for (int i = 0; i < len; i++)        // Confere cada segmento da cobra...
        if (sx[i] == fx && sy[i] == fy) {  // ...se a comida caiu em cima da cobra...
          ok = false;                      // ...a posição não vale
          break;                           // ...e para de conferir
        }
    } while (!ok);                         // Se não valeu, sorteia de novo
  };

  // Posição inicial da cobra: horizontal, no meio da altura da grade
  for (int i = 0; i < len; i++) {
    sx[i] = len - 1 - i;                   // Cabeça na coluna 3, corpo nas colunas 2, 1 e 0
    sy[i] = SN_ROWS / 2;                   // Todos na linha do meio
  }
  placeFood();                             // Coloca a primeira comida

  // Brief instructions
  u8g2.clearBuffer();                      // Limpa o buffer da tela
  u8g2.setFont(u8g2_font_ncenB10_tr);      // Fonte grande para o título
  centreStr("SNAKE", 24);                  // Título centralizado
  u8g2.setFont(u8g2_font_6x10_tr);         // Fonte pequena para as instruções
  centreStr("Use buttons to steer", 40);   // Explica os controles
  centreStr("Eat to grow!", 54);           // Objetivo: comer para crescer
  u8g2.sendBuffer();                       // Envia o buffer para o display
  delay(1400);                             // Deixa o jogador ler por 1,4 segundo
  waitRelease();                           // Garante que nenhum botão esteja apertado ao começar

  // ── Loop principal do jogo ──
  while (true) {
    // Direction input (buffer the next move)
    // Validate against current direction (dx, dy) to prevent U-turn
    // Os botões só definem a PRÓXIMA direção. Cada botão só vale se a cobra
    // não estiver andando no mesmo eixo (assim não dá meia-volta em cima de si mesma).
    if (btnHeld(BTN_UP) && dy == 0) {      // CIMA só vale se a cobra está andando na horizontal
      next_dx = 0;
      next_dy = -1;                        // Para cima (Y diminui)
    }
    if (btnHeld(BTN_DOWN) && dy == 0) {    // BAIXO só vale se a cobra está andando na horizontal
      next_dx = 0;
      next_dy = 1;                         // Para baixo (Y aumenta)
    }
    if (btnHeld(BTN_LEFT) && dx == 0) {    // ESQUERDA só vale se a cobra está andando na vertical
      next_dx = -1;                        // Para a esquerda (X diminui)
      next_dy = 0;
    }
    if (btnHeld(BTN_RIGHT) && dx == 0) {   // DIREITA só vale se a cobra está andando na vertical
      next_dx = 1;                         // Para a direita (X aumenta)
      next_dy = 0;
    }

    uint32_t now = millis();               // Hora atual em ms
    if (now - lastMove < spd) {            // Ainda não é hora do próximo passo?
      delay(8);                            // Espera um pouco...
      continue;                            // ...e volta ao início do loop (continua lendo os botões)
    }
    lastMove = now;                        // Anota o momento deste passo

    // Apply buffered direction
    dx = next_dx;                          // Passa a valer a direção escolhida
    dy = next_dy;

    // Next head position (wrap at borders)
    // Nova posição da cabeça. O "%" faz a cobra reaparecer do lado oposto ao sair da grade;
    // somar SN_COLS / SN_ROWS evita resultados negativos.
    int nx = (sx[0] + dx + SN_COLS) % SN_COLS;
    int ny = (sy[0] + dy + SN_ROWS) % SN_ROWS;

    // Self-collision check
    for (int i = 1; i < len; i++) {        // Confere o corpo (do índice 1 em diante)...
      if (sx[i] == nx && sy[i] == ny) {    // ...se a nova cabeça cairia sobre o corpo...
        gameOver(score);                   // ...mostra Game Over com a pontuação
        return;                            // ...e volta ao menu
      }
    }

    // Shift body
    // Cada segmento assume a posição do segmento da frente (do rabo para a cabeça)
    for (int i = len - 1; i > 0; i--) {
      sx[i] = sx[i - 1];
      sy[i] = sy[i - 1];
    }
    sx[0] = nx;                            // A cabeça vai para a nova posição
    sy[0] = ny;

    // Eat food?
    if (nx == fx && ny == fy) {            // A cabeça chegou na comida?
      score++;                             // Ganha 1 ponto
      if (len < SN_MAXLEN)                 // Se ainda não atingiu o tamanho máximo...
        len++;                             // ...a cobra cresce 1 segmento
                                           // (o novo segmento só recebe posição válida no próximo passo)
      spd = max(70, (int)spd - 7);         // Fica 7 ms mais rápida, com mínimo de 70 ms por passo
      beep(1400, 35);                      // Som de comer
      placeFood();                         // Sorteia nova posição para a comida
    }

    // ── Draw ──
    uint8_t ox = SN_OFFX, oy = SN_OFFY;    // Deslocamento da grade na tela
    u8g2.clearBuffer();                    // Limpa o buffer

    // Playfield border
    // Moldura em volta da área de jogo (1 px maior que a grade em cada lado)
    u8g2.drawFrame(ox - 1, oy - 1, SN_COLS * SN_SZ + 2, SN_ROWS * SN_SZ + 2);

    // Snake
    for (int i = 0; i < len; i++) {        // Para cada segmento da cobra...
      int px = ox + sx[i] * SN_SZ;         // ...calcula a posição X em pixels
      int py = oy + sy[i] * SN_SZ;         // ...e a posição Y em pixels
      if (i == 0)                          // Cabeça:
        u8g2.drawBox(px, py, SN_SZ, SN_SZ); // solid head (quadrado cheio)
      else                                 // Corpo:
        u8g2.drawFrame(px + 1, py + 1, SN_SZ - 2, SN_SZ - 2); // hollow body (quadrado vazado, menor)
    }

    // Food (small filled square)
    u8g2.drawBox(ox + fx * SN_SZ + 1, oy + fy * SN_SZ + 1, SN_SZ - 2,
                 SN_SZ - 2);               // Comida: quadradinho cheio dentro da célula

    // Score panel (right of grid)
    u8g2.setFont(u8g2_font_5x7_tr);        // Fonte bem pequena para o placar
    // Atenção: a grade ocupa 1 + 21*6 = 127 px, então x = 131 fica FORA da tela (128 px);
    // por isso o placar provavelmente não aparece no display.
    u8g2.drawStr(ox + SN_COLS * SN_SZ + 4, oy + 8, "SC");   // Texto "SC" (score)
    char sc[6];                            // Texto onde o número será guardado
    itoa(score, sc, 10);                   // Converte a pontuação em texto (base 10)
    u8g2.drawStr(ox + SN_COLS * SN_SZ + 4, oy + 18, sc);    // Número da pontuação

    u8g2.sendBuffer();                     // Envia o quadro pronto ao display
  }
}

#endif                       // Fim da guarda de inclusão
