#ifndef DINO_H               // Guarda de inclusão: só compila se DINO_H ainda não foi definido
#define DINO_H               // Define DINO_H para o arquivo não ser incluído duas vezes

#include <Arduino.h>         // Funções básicas do Arduino (millis, delay, random, itoa...)
#include <U8g2lib.h>         // Biblioteca gráfica do display OLED

// As linhas "extern" avisam que estas coisas já existem no arquivo principal (.ino)
extern U8G2_SSD1306_128X64_NONAME_F_HW_I2C u8g2;     // O objeto do display
extern bool btnPressed(uint8_t pin);                 // Detecta o instante em que um botão é apertado
extern bool btnHeld(uint8_t pin);                    // Detecta se um botão está sendo segurado
extern void beep(uint16_t freq, uint16_t ms);        // Toca um som no buzzer
extern void waitRelease();                           // Espera soltar todos os botões
extern void centreStr(const char *s, uint8_t y);     // Escreve texto centralizado
extern void gameOver(uint16_t score);                // Tela de Game Over com a pontuação

// Função principal do jogo; é chamada pelo menu e retorna quando o jogador perde
void game_dino() {
  const float GRAVITY = 0.6f;       // Gravidade: quanto a velocidade vertical aumenta (para baixo) a cada frame
  const float JUMP_FORCE = -6.5f;   // Impulso do pulo (negativo = para cima, pois o Y cresce para baixo)
  const int DINO_X = 15;            // Posição X fixa do dinossauro
  const int GROUND_Y = 58;          // Altura (Y) da linha do chão

  float dinoY = GROUND_Y - 12;      // Posição Y inicial do dino: em pé sobre o chão (altura do dino = 12)
  float velY = 0;                   // Velocidade vertical atual do dino
  bool isJumping = false;           // true enquanto o dino está no ar

  float obsX = 130;                 // Posição X do obstáculo: começa fora da tela, à direita
  int obsType = 0; // 0: Small cactus, 1: Large cactus, 2: Bird   // Tipo do obstáculo atual
  float obsSpeed = 3.5f;            // Velocidade do obstáculo (aumenta com o tempo)

  uint16_t score = 0;               // Pontuação: conta obstáculos ultrapassados
  uint32_t lastFrame = millis();    // Momento do último frame (para calcular dt)

  // ── Tela de instruções ──
  u8g2.clearBuffer();                       // Limpa o buffer da tela
  u8g2.setFont(u8g2_font_ncenB10_tr);       // Fonte grande para o título
  centreStr("DINO RUN", 24);                // Título centralizado
  u8g2.setFont(u8g2_font_6x10_tr);          // Fonte pequena para as instruções
  centreStr("PRESS ANY BTN", 40);           // Explica o controle (qualquer botão pula)
  centreStr("Avoid obstacles!", 54);        // Objetivo
  u8g2.sendBuffer();                        // Envia o buffer para o display
  delay(1500);                              // Deixa o jogador ler por 1,5 segundo
  waitRelease();                            // Garante que nenhum botão esteja apertado ao começar

  // ── Loop principal do jogo (1 volta = 1 frame) ──
  while (true) {
    uint32_t now = millis();                // Hora atual em ms
    float dt = (now - lastFrame) / 20.0f;   // Fator de tempo desde o último frame (≈1.0 a 20 ms)
    if (dt > 2.0f)                          // Limita o dt para o jogo não "dar um salto"
      dt = 2.0f;                            // caso algum frame demore demais
    lastFrame = now;                        // Guarda a hora deste frame

    // Jump logic
    // Jump logic (Any button)
    // Verdadeiro se QUALQUER um dos 4 botões acabou de ser apertado
    bool anyBtn = btnPressed(BTN_UP) || btnPressed(BTN_DOWN) ||
                  btnPressed(BTN_LEFT) || btnPressed(BTN_RIGHT);
    if (anyBtn && !isJumping) {             // Só pula se apertou um botão e já não está no ar
      velY = JUMP_FORCE;                    // Dá o impulso para cima
      isJumping = true;                     // Marca que está pulando
      beep(1000, 20);                       // Som curto de pulo
    }

    velY += GRAVITY * dt;                   // A gravidade vai aumentando a velocidade para baixo
    dinoY += velY * dt;                     // Atualiza a posição vertical com a velocidade

    if (dinoY >= GROUND_Y - 12) {           // Se chegou ao chão (ou passou dele)...
      dinoY = GROUND_Y - 12;                // ...fixa o dino exatamente sobre o chão
      velY = 0;                             // ...zera a velocidade vertical
      isJumping = false;                    // ...e permite pular de novo
    }

    // Obstacle logic
    obsX -= obsSpeed * dt;                  // Move o obstáculo para a esquerda
    if (obsX < -20) {                       // Se saiu totalmente da tela pela esquerda...
      obsX = 130 + random(0, 50);           // ...reaparece à direita, com distância aleatória
      obsType = random(0, 3);               // ...sorteia o tipo (0, 1 ou 2)
      score++;                              // ...e o jogador ganha 1 ponto
      obsSpeed += 0.05f;                    // ...o jogo fica um pouco mais rápido
      if (score % 5 == 0)                   // A cada 5 pontos...
        beep(1500, 30);                     // ...toca um som de comemoração
    }

    // Collision detection
    int dinoW = 10, dinoH = 12;             // Largura e altura da "caixa" do dino
    int obsW, obsH, obsY;                   // Largura, altura e posição Y do obstáculo (depende do tipo)
    if (obsType == 0) {                     // Cacto pequeno
      obsW = 6;
      obsH = 10;
      obsY = GROUND_Y - 10;                 // Apoiado no chão
    } else if (obsType == 1) {              // Cacto grande
      obsW = 10;
      obsH = 14;
      obsY = GROUND_Y - 14;                 // Apoiado no chão
    } else {                                // Pássaro
      obsW = 8;
      obsH = 6;
      obsY = GROUND_Y - 25;                 // Voa alto: o dino passa por baixo se não pular
    } // Bird

    // Colisão entre retângulos: há batida se os dois se sobrepõem na horizontal E na vertical
    if (DINO_X < obsX + obsW && DINO_X + dinoW > obsX && dinoY < obsY + obsH &&
        dinoY + dinoH > obsY) {
      gameOver(score);                      // Bateu: mostra Game Over com a pontuação
      return;                               // Encerra o jogo e volta ao menu
    }

    // ── Draw ──
    u8g2.clearBuffer();                     // Limpa o buffer para desenhar o novo quadro

    // Ground
    u8g2.drawHLine(0, GROUND_Y, SCREEN_W);  // Linha horizontal do chão, de ponta a ponta
    for (int i = 0; i < SCREEN_W; i += 10)  // Pontinhos abaixo do chão, de 10 em 10 pixels...
      u8g2.drawPixel(i + ((now / 50) % 10), GROUND_Y + 2); // ...deslocados pelo tempo, para dar efeito de movimento

    // Dino
    u8g2.drawFrame(DINO_X, (int)dinoY, 10, 12);      // Corpo do dino: retângulo de 10x12
    u8g2.drawBox(DINO_X + 7, (int)dinoY + 2, 2, 2);  // Eye  (olho: quadradinho preenchido)
    if (!isJumping) {                                // Só desenha as pernas se estiver no chão
      if ((now / 100) % 2 == 0)                      // Alterna a cada 100 ms entre duas posições...
        u8g2.drawBox(DINO_X + 2, (int)dinoY + 12, 2, 2); // ...perna esquerda
      else
        u8g2.drawBox(DINO_X + 6, (int)dinoY + 12, 2, 2); // ...perna direita (efeito de corrida)
    }

    // Obstacles
    if (obsType == 0) { // Small cactus
      u8g2.drawBox((int)obsX + 2, (int)obsY, 2, 10);     // Tronco do cacto
      u8g2.drawPixel((int)obsX, (int)obsY + 2);          // Pequeno "braço" esquerdo
      u8g2.drawPixel((int)obsX + 4, (int)obsY + 1);      // Pequeno "braço" direito
    } else if (obsType == 1) { // Large cactus
      u8g2.drawBox((int)obsX + 3, (int)obsY, 4, 14);     // Tronco grande
      u8g2.drawBox((int)obsX, (int)obsY + 4, 2, 6);      // Braço esquerdo
      u8g2.drawBox((int)obsX + 8, (int)obsY + 3, 2, 7);  // Braço direito
    } else { // Bird
      if (obsX > -10 && obsX < SCREEN_W + 10) {          // Só desenha se estiver (quase) visível
        u8g2.drawFrame((int)obsX, (int)obsY, 8, 4);      // Corpo do pássaro
        if ((now / 150) % 2 == 0)                        // Alterna a cada 150 ms (bater de asas)...
          u8g2.drawLine((int)obsX, (int)obsY, (int)obsX - 4, (int)obsY - 2);       // ...asa para cima
        else
          u8g2.drawLine((int)obsX, (int)obsY + 4, (int)obsX - 4, (int)obsY + 6);   // ...asa para baixo
      }
    }

    // Score
    u8g2.setFont(u8g2_font_6x10_tr);        // Fonte do placar
    char sc[6];                             // Texto onde o número será guardado
    itoa(score, sc, 10);                    // Converte a pontuação em texto (base 10)
    u8g2.drawStr(100, 10, sc);              // Escreve no canto superior direito

    u8g2.sendBuffer();                      // Envia o quadro pronto ao display

    // Controle de velocidade: tenta manter ~50 frames por segundo (20 ms por frame)
    int32_t wait = 20 - (int32_t)(millis() - now);   // Quanto falta para completar 20 ms
    if (wait > 0)                           // Se o frame foi mais rápido que isso...
      delay(wait);                          // ...espera o restante
  }
}

#endif                       // Fim da guarda de inclusão
