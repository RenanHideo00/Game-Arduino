#ifndef PACMAN_H             // Guarda de inclusão: só compila se PACMAN_H ainda não foi definido
#define PACMAN_H             // Define PACMAN_H para o arquivo não ser incluído duas vezes

#include <Arduino.h>         // Funções básicas do Arduino (millis, delay, abs, itoa...)
#include <U8g2lib.h>         // Biblioteca gráfica do display OLED

// As linhas "extern" avisam que estas coisas já existem no arquivo principal (.ino)
extern U8G2_SSD1306_128X64_NONAME_F_HW_I2C u8g2;     // O objeto do display
extern bool btnPressed(uint8_t pin);                 // Detecta o instante em que um botão é apertado
extern bool btnHeld(uint8_t pin);                    // Detecta se um botão está sendo segurado
extern void beep(uint16_t freq, uint16_t ms);        // Toca um som no buzzer
extern void waitRelease();                           // Espera soltar todos os botões
extern void centreStr(const char *s, uint8_t y);     // Escreve texto centralizado
extern void gameOver(uint16_t score);                // Tela de Game Over com a pontuação

#define PAC_SIZE 12          // Tamanho de referência (não é usado no código)
#define PAC_MAZE_W 10        // Número de colunas da grade de pontinhos
#define PAC_MAZE_H 5         // Número de linhas da grade de pontinhos

// Função principal do jogo; é chamada pelo menu e retorna quando o jogo termina
void game_pacman() {
  int px = 64, py = 32;      // Posição do Pac-Man (em pixels): começa no centro da tela
  int pdx = 0, pdy = 0;      // Direção atual do Pac-Man (quanto anda em X e Y por frame)
  int score = 0;             // Pontuação

  bool maze[PAC_MAZE_H][PAC_MAZE_W];       // Grade de pontinhos: true = pontinho ainda existe
  for (int y = 0; y < PAC_MAZE_H; y++)     // Percorre cada linha...
    for (int x = 0; x < PAC_MAZE_W; x++)   // ...e cada coluna...
      maze[y][x] = true;                   // ...e coloca um pontinho em todas as posições

  int gx = 10, gy = 10;      // Posição do fantasma (em pixels): começa no canto superior esquerdo
  int gDir = 0; // 0:R, 1:L, 2:D, 3:U      // Direção do fantasma (declarada, mas não usada no código)

  // ── Tela de instruções ──
  u8g2.clearBuffer();                      // Limpa o buffer da tela
  u8g2.setFont(u8g2_font_ncenB10_tr);      // Fonte grande para o título
  centreStr("PAC-MAN", 24);                // Título centralizado
  u8g2.setFont(u8g2_font_6x10_tr);         // Fonte pequena para as instruções
  centreStr("Use Buttons to Move", 40);    // Explica os controles
  centreStr("Eat all dots!", 54);          // Objetivo: comer todos os pontinhos
  u8g2.sendBuffer();                       // Envia o buffer para o display
  delay(1500);                             // Deixa o jogador ler por 1,5 segundo
  waitRelease();                           // Garante que nenhum botão esteja apertado ao começar

  // ── Loop principal do jogo (1 volta = 1 frame) ──
  while (true) {
    uint32_t start = millis();             // Hora do início deste frame

    // Leitura dos botões: define a direção (2 pixels por frame).
    // O Pac-Man continua andando na última direção escolhida, mesmo sem segurar o botão.
    if (btnHeld(BTN_UP)) {
      pdx = 0;               // Sem movimento horizontal
      pdy = -2;              // Para cima (Y diminui)
    }
    if (btnHeld(BTN_DOWN)) {
      pdx = 0;
      pdy = 2;               // Para baixo (Y aumenta)
    }
    if (btnHeld(BTN_LEFT)) {
      pdx = -2;              // Para a esquerda (X diminui)
      pdy = 0;
    }
    if (btnHeld(BTN_RIGHT)) {
      pdx = 2;               // Para a direita (X aumenta)
      pdy = 0;
    }

    px += pdx;               // Move o Pac-Man na horizontal
    py += pdy;               // Move o Pac-Man na vertical

    // Boundaries
    // Impede o Pac-Man de sair da tela (margem de 4 px, que é o raio dele)
    if (px < 4)
      px = 4;
    if (px > SCREEN_W - 4)
      px = SCREEN_W - 4;
    if (py < 4)
      py = 4;
    if (py > SCREEN_H - 4)
      py = SCREEN_H - 4;

    // Dot eating
    // Converte a posição em pixels para a célula da grade (a tela é dividida em 10x5 células)
    int mx = (px * PAC_MAZE_W) / SCREEN_W;   // Coluna da grade onde o Pac-Man está
    int my = (py * PAC_MAZE_H) / SCREEN_H;   // Linha da grade onde o Pac-Man está
    if (mx >= 0 && mx < PAC_MAZE_W && my >= 0 && my < PAC_MAZE_H) {  // Garante que está dentro da grade
      if (maze[my][mx]) {                    // Se ainda há pontinho nesta célula...
        maze[my][mx] = false;                // ...come o pontinho
        score += 10;                         // ...ganha 10 pontos
        beep(1000, 10);                      // ...e toca um som curto
      }
    }

    // Ghost AI (Slower)
    static uint8_t gSpeedCount = 0;          // Contador de frames (static: mantém o valor entre chamadas)
    if (++gSpeedCount % 2 == 0) {            // Só move o fantasma a cada 2 frames (ele é mais lento que o Pac-Man)
      if (gx < px)                           // Se o fantasma está à esquerda do Pac-Man...
        gx++;                                // ...anda 1 pixel para a direita
      else if (gx > px)                      // Se está à direita...
        gx--;                                // ...anda 1 pixel para a esquerda
      if (gy < py)                           // Se está acima do Pac-Man...
        gy++;                                // ...anda 1 pixel para baixo
      else if (gy > py)                      // Se está abaixo...
        gy--;                                // ...anda 1 pixel para cima
    }

    // Collision
    // Se a distância nos dois eixos for menor que 6 pixels, o fantasma pegou o Pac-Man
    if (abs(px - gx) < 6 && abs(py - gy) < 6) {
      gameOver(score);                       // Mostra Game Over com a pontuação
      return;                                // Encerra o jogo e volta ao menu
    }

    // Win check
    bool win = true;                         // Supõe que o jogador venceu...
    for (int y = 0; y < PAC_MAZE_H; y++)
      for (int x = 0; x < PAC_MAZE_W; x++)
        if (maze[y][x])                      // ...mas se ainda restar algum pontinho...
          win = false;                       // ...então ainda não venceu

    if (win) {                               // Comeu todos os pontinhos?
      u8g2.clearBuffer();                    // Limpa a tela
      u8g2.setFont(u8g2_font_ncenB10_tr);    // Fonte grande
      centreStr("YOU WIN!", 32);             // Mensagem de vitória
      u8g2.sendBuffer();                     // Envia para o display
      delay(2000);                           // Mostra por 2 segundos
      return;                                // Encerra o jogo e volta ao menu
    }

    // ── Desenho do frame ──
    u8g2.clearBuffer();                      // Limpa o buffer para desenhar o novo quadro

    // Draw dots
    for (int y = 0; y < PAC_MAZE_H; y++) {
      for (int x = 0; x < PAC_MAZE_W; x++) {
        if (maze[y][x]) {                    // Só desenha onde o pontinho ainda existe
          // Calcula o centro da célula: início da célula + metade do tamanho dela
          int dx = (x * SCREEN_W / PAC_MAZE_W) + (SCREEN_W / (PAC_MAZE_W * 2));
          int dy = (y * SCREEN_H / PAC_MAZE_H) + (SCREEN_H / (PAC_MAZE_H * 2));
          u8g2.drawPixel(dx, dy);            // Desenha o pontinho (1 pixel)
        }
      }
    }

    // Draw Pac
    u8g2.drawDisc(px, py, 4);                // Pac-Man: círculo preenchido de raio 4
    // Draw Ghost
    u8g2.drawFrame(gx - 3, gy - 3, 7, 7);    // Fantasma: contorno quadrado de 7x7 centralizado em (gx, gy)
    u8g2.drawPixel(gx - 1, gy - 1);          // Olho esquerdo
    u8g2.drawPixel(gx + 1, gy - 1);          // Olho direito

    u8g2.setFont(u8g2_font_5x7_tr);          // Fonte bem pequena para o placar
    char sc[10];                             // Texto onde o número será guardado
    itoa(score, sc, 10);                     // Converte a pontuação em texto (base 10)
    u8g2.drawStr(1, 63, sc);                 // Escreve no canto inferior esquerdo

    u8g2.sendBuffer();                       // Envia o quadro pronto ao display

    // Controle de velocidade: tenta manter ~33 frames por segundo (30 ms por frame)
    int32_t wait = 30 - (int32_t)(millis() - start);   // Quanto falta para completar 30 ms
    if (wait > 0)                            // Se o frame foi mais rápido que isso...
      delay(wait);                           // ...espera o restante
  }
}

#endif                       // Fim da guarda de inclusão
