#ifndef TETRIS_H             // Guarda de inclusão: só compila se TETRIS_H ainda não foi definido
#define TETRIS_H             // Define TETRIS_H para o arquivo não ser incluído duas vezes

#include <Arduino.h>         // Funções básicas do Arduino (millis, delay, memcpy, memset, pgm_read_byte...)
#include <U8g2lib.h>         // Biblioteca gráfica do display OLED

// As linhas "extern" avisam que estas coisas já existem no arquivo principal (.ino)
extern U8G2_SSD1306_128X64_NONAME_F_HW_I2C u8g2;     // O objeto do display
extern bool btnPressed(uint8_t pin);                 // Detecta o instante em que um botão é apertado
extern bool btnHeld(uint8_t pin);                    // Detecta se um botão está sendo segurado
extern void beep(uint16_t freq, uint16_t ms);        // Toca um som no buzzer
extern void waitRelease();                           // Espera soltar todos os botões
extern void centreStr(const char *s, uint8_t y);     // Escreve texto centralizado
extern void gameOver(uint16_t score);                // Tela de Game Over com a pontuação

#define TT_COLS 8            // Largura do tabuleiro, em células
#define TT_ROWS 13           // Altura do tabuleiro, em células
#define TT_SZ 5              // Tamanho de cada célula, em pixels
#define TT_OX 44             // Posição X do tabuleiro na tela
#define TT_OY 2              // Posição Y do tabuleiro na tela

// Estrutura que representa uma peça do Tetris
struct TetPiece {
  int8_t x, y;               // Posição da peça no tabuleiro (em células)
  uint8_t type;              // Tipo da peça (0 a 6)
  int8_t cells[4][2];        // Os 4 quadradinhos da peça: [i][0] = X relativo, [i][1] = Y relativo
  void load(uint8_t t);      // Carrega o formato de um tipo de peça (definida mais abaixo)
  // Calcula a posição absoluta (no tabuleiro) de cada um dos 4 quadradinhos
  void getAbs(int8_t out[4][2]) const {
    for (int i = 0; i < 4; i++) {
      out[i][0] = x + cells[i][0];       // X absoluto = posição da peça + X relativo
      out[i][1] = y + cells[i][1];       // Y absoluto = posição da peça + Y relativo
    }
  }
};

// Formato das 7 peças: cada uma tem 4 quadradinhos com coordenadas (x, y).
// PROGMEM guarda a tabela na memória flash (e não na RAM, que é pequena).
const int8_t PIECES[7][4][2] PROGMEM = {
    {{0, 0}, {1, 0}, {2, 0}, {3, 0}}, // I
    {{0, 0}, {0, 1}, {1, 1}, {2, 1}}, // J
    {{2, 0}, {0, 1}, {1, 1}, {2, 1}}, // L
    {{0, 0}, {1, 0}, {1, 1}, {2, 1}}, // S
    {{1, 0}, {2, 0}, {0, 1}, {1, 1}}, // Z
    {{1, 0}, {0, 1}, {1, 1}, {2, 1}}, // T
    {{0, 0}, {1, 0}, {0, 1}, {1, 1}}, // O
};

uint8_t board[TT_ROWS][TT_COLS];   // Tabuleiro: 0 = célula vazia, 1 = célula ocupada

// Carrega o formato da peça do tipo "t" lendo a tabela da memória flash
void TetPiece::load(uint8_t t) {
  type = t;                                          // Guarda o tipo
  for (int i = 0; i < 4; i++) {
    cells[i][0] = pgm_read_byte(&PIECES[t][i][0]);   // Lê o X relativo do quadradinho i
    cells[i][1] = pgm_read_byte(&PIECES[t][i][1]);   // Lê o Y relativo do quadradinho i
  }
}

// Verifica se a peça "p", deslocada de (dx, dy), cabe no tabuleiro (sem sair nem bater em blocos)
bool ttFits(const TetPiece &p, int dx, int dy) {
  for (int i = 0; i < 4; i++) {                 // Confere cada um dos 4 quadradinhos
    int nx = p.x + p.cells[i][0] + dx;          // Coluna onde ele ficaria
    int ny = p.y + p.cells[i][1] + dy;          // Linha onde ele ficaria
    if (nx < 0 || nx >= TT_COLS || ny >= TT_ROWS)   // Fora das laterais ou abaixo do fundo?
      return false;                             // Não cabe
    if (ny >= 0 && board[ny][nx])               // Dentro do tabuleiro e a célula já está ocupada?
      return false;                             // Não cabe (acima do topo, ny < 0, é permitido)
  }
  return true;                                  // Todos os quadradinhos couberam
}

// Gira a peça 90 graus em torno do primeiro quadradinho (cells[0])
void ttRotate(TetPiece &p) {
  int8_t tmp[4][2];                             // Guarda o resultado da rotação
  for (int i = 0; i < 4; i++) {
    int8_t rx = p.cells[i][0] - p.cells[0][0];  // Posição do quadradinho relativa ao pivô (X)
    int8_t ry = p.cells[i][1] - p.cells[0][1];  // Posição do quadradinho relativa ao pivô (Y)
    tmp[i][0] = p.cells[0][0] - ry;             // Rotação: novo X = pivô X - ry
    tmp[i][1] = p.cells[0][1] + rx;             // Rotação: novo Y = pivô Y + rx
  }
  int8_t saved[4][2];                           // Cópia do formato original
  memcpy(saved, p.cells, sizeof(saved));        // Guarda o formato original
  memcpy(p.cells, tmp, sizeof(tmp));            // Aplica o formato girado
  if (!ttFits(p, 0, 0))                         // Se a peça girada não cabe...
    memcpy(p.cells, saved, sizeof(saved));      // ...desfaz a rotação (volta ao formato original)
}

// Função principal do jogo; é chamada pelo menu e retorna quando a pilha chega ao topo
void game_tetris() {
  memset(board, 0, sizeof(board));              // Esvazia o tabuleiro
  uint16_t score = 0;                           // Pontuação
  uint8_t level = 1;                            // Nível (aumenta com a pontuação)
  // dropInterval = tempo (ms) entre quedas automáticas; lastDrop = última queda; lastMove = último movimento lateral
  uint32_t dropInterval = 600, lastDrop = millis(), lastMove = 0;
  TetPiece cur, next;                           // cur = peça atual; next = próxima peça
  cur.load(random(0, 7));                       // Sorteia a peça atual (tipos 0 a 6)
  cur.x = TT_COLS / 2 - 1;                      // Posiciona no meio do tabuleiro...
  cur.y = 0;                                    // ...no topo
  next.load(random(0, 7));                      // Sorteia a próxima peça
  next.x = TT_COLS / 2 - 1;
  next.y = 0;

  // ── Tela de instruções ──
  u8g2.clearBuffer();                           // Limpa o buffer da tela
  u8g2.setFont(u8g2_font_ncenB10_tr);           // Fonte grande para o título
  centreStr("TETRIS", 24);                      // Título centralizado
  u8g2.setFont(u8g2_font_6x10_tr);              // Fonte pequena para as instruções
  centreStr("L/R=move  UP=rot", 40);            // Esquerda/direita move; CIMA gira
  centreStr("DN=fast drop", 54);                // BAIXO acelera a queda
  u8g2.sendBuffer();                            // Envia o buffer para o display
  delay(1500);                                  // Deixa o jogador ler por 1,5 segundo
  waitRelease();                                // Garante que nenhum botão esteja apertado ao começar

  // ── Loop principal do jogo ──
  while (true) {
    uint32_t now = millis();                    // Hora atual em ms

    // Movimento lateral: no máximo 1 passo a cada 130 ms (para não correr rápido demais)
    if (now - lastMove > 130) {
      if (btnHeld(BTN_LEFT) && ttFits(cur, -1, 0)) {    // ESQUERDA segurado e cabe uma célula à esquerda?
        cur.x--;                                // Move a peça para a esquerda
        lastMove = now;                         // Anota o momento do movimento
        beep(700, 15);                          // Som curto
      }
      if (btnHeld(BTN_RIGHT) && ttFits(cur, 1, 0)) {    // DIREITA segurado e cabe uma célula à direita?
        cur.x++;                                // Move a peça para a direita
        lastMove = now;
        beep(700, 15);
      }
    }
    if (btnPressed(BTN_UP)) {                   // CIMA apertado (uma vez por aperto)...
      ttRotate(cur);                            // ...gira a peça
      beep(900, 15);                            // Som curto
    }

    // Queda: com BAIXO segurado cai a cada 60 ms; senão, no intervalo normal do nível
    uint32_t interval = btnHeld(BTN_DOWN) ? 60 : dropInterval;
    if (now - lastDrop > interval) {            // Chegou a hora de cair uma linha?
      lastDrop = now;                           // Anota o momento da queda
      if (ttFits(cur, 0, 1))                    // Se cabe uma linha abaixo...
        cur.y++;                                // ...a peça desce
      else {                                    // Senão, a peça pousou: trava no tabuleiro
        int8_t abs[4][2];                       // Posições absolutas dos 4 quadradinhos
        cur.getAbs(abs);                        // Calcula as posições
        for (int i = 0; i < 4; i++)
          if (abs[i][1] >= 0)                   // Só grava quadradinhos que estão dentro do tabuleiro
            board[abs[i][1]][abs[i][0]] = 1;    // Marca a célula como ocupada
        beep(500, 20);                          // Som de peça pousando

        // Limpeza de linhas completas
        int cleared = 0;                        // Quantidade de linhas removidas
        for (int r = TT_ROWS - 1; r >= 0; r--) {      // Percorre de baixo para cima
          bool full = true;                     // Supõe que a linha está cheia...
          for (int c = 0; c < TT_COLS; c++)
            if (!board[r][c]) {                 // ...mas se achar uma célula vazia...
              full = false;                     // ...a linha não está cheia
              break;
            }
          if (full) {                           // Linha completa?
            cleared++;                          // Conta mais uma linha removida
            for (int rr = r; rr > 0; rr--)      // Desce tudo que está acima dela, uma linha
              memcpy(board[rr], board[rr - 1], TT_COLS);   // Copia a linha de cima para esta
            memset(board[0], 0, TT_COLS);       // A linha do topo fica vazia
            r++;                                // Confere a mesma posição de novo (veio uma linha nova para ela)
          }
        }
        if (cleared) {                          // Se removeu alguma linha...
          static const uint16_t pts[5] = {0, 40, 100, 300, 1200};   // Pontos por 0, 1, 2, 3 ou 4 linhas
          score += pts[min(cleared, 4)] * level;    // Soma os pontos, multiplicados pelo nível
          beep(1200, 40);                       // Dois bipes de comemoração
          delay(45);
          beep(1400, 40);
          level = 1 + score / 200;              // Sobe de nível a cada 200 pontos
          dropInterval = max(80U, 600U - (level - 1) * 60);  // Queda mais rápida: -60 ms por nível, mínimo 80 ms
        }

        // Próxima peça
        cur = next;                             // A "próxima" vira a peça atual
        cur.x = TT_COLS / 2 - 1;                // Posiciona no meio...
        cur.y = 0;                              // ...no topo
        next.load(random(0, 7));                // Sorteia uma nova "próxima" peça
        if (!ttFits(cur, 0, 0)) {               // Se a nova peça já não cabe, a pilha chegou ao topo
          gameOver(score);                      // Mostra Game Over com a pontuação
          return;                               // Encerra o jogo e volta ao menu
        }
      }
    }

    // ── Desenho do frame ──
    u8g2.clearBuffer();                         // Limpa o buffer para desenhar o novo quadro
    // Moldura em volta do tabuleiro (1 px maior em cada lado)
    u8g2.drawFrame(TT_OX - 1, TT_OY - 1, TT_COLS * TT_SZ + 2,
                   TT_ROWS * TT_SZ + 2);
    // Blocos já fixados no tabuleiro
    for (int r = 0; r < TT_ROWS; r++)
      for (int c = 0; c < TT_COLS; c++)
        if (board[r][c])                        // Célula ocupada: desenha um quadradinho
          u8g2.drawBox(TT_OX + c * TT_SZ, TT_OY + r * TT_SZ, TT_SZ - 1,
                       TT_SZ - 1);              // (1 px menor que a célula, para dar espaço entre blocos)
    // Peça atual
    int8_t abs[4][2];                           // Posições absolutas dos 4 quadradinhos
    cur.getAbs(abs);                            // Calcula as posições
    for (int i = 0; i < 4; i++)
      if (abs[i][1] >= 0)                       // Só desenha o que está dentro do tabuleiro
        u8g2.drawBox(TT_OX + abs[i][0] * TT_SZ, TT_OY + abs[i][1] * TT_SZ,
                     TT_SZ - 1, TT_SZ - 1);
    // "Fantasma": mostra onde a peça vai pousar se cair direto
    TetPiece ghost = cur;                       // Copia a peça atual
    while (ttFits(ghost, 0, 1))                 // Desce a cópia até não caber mais
      ghost.y++;
    ghost.getAbs(abs);                          // Posições absolutas da cópia
    for (int i = 0; i < 4; i++)
      // Só desenha o contorno se não for o mesmo lugar da peça atual
      if (abs[i][1] >= 0 && abs[i][1] != cur.y + cur.cells[i][1])
        u8g2.drawFrame(TT_OX + abs[i][0] * TT_SZ + 1,
                       TT_OY + abs[i][1] * TT_SZ + 1, TT_SZ - 3, TT_SZ - 3);

    // Painel lateral esquerdo
    u8g2.setFont(u8g2_font_5x7_tr);             // Fonte bem pequena
    u8g2.drawStr(1, 10, "SCR");                 // Rótulo da pontuação
    char sc[8];                                 // Texto da pontuação
    itoa(score, sc, 10);                        // Converte a pontuação em texto
    u8g2.drawStr(1, 18, sc);                    // Mostra a pontuação
    u8g2.drawStr(1, 30, "LVL");                 // Rótulo do nível
    char lv[4];                                 // Texto do nível
    itoa(level, lv, 10);                        // Converte o nível em texto
    u8g2.drawStr(1, 38, lv);                    // Mostra o nível
    u8g2.drawStr(1, 50, "NXT");                 // Rótulo da próxima peça
    int8_t nabs[4][2];                          // Posições da próxima peça
    next.getAbs(nabs);                          // Calcula as posições
    for (int i = 0; i < 4; i++)                 // Desenha a próxima peça em miniatura (quadradinhos de 3 px a cada 4 px)
      u8g2.drawBox(4 + nabs[i][0] * 4, 52 + nabs[i][1] * 4, 3, 3);
    u8g2.sendBuffer();                          // Envia o quadro pronto ao display

    // Controle de velocidade: tenta manter ~60 frames por segundo (16 ms por frame)
    int32_t wait = 16 - (int32_t)(millis() - now);   // Quanto falta para completar 16 ms
    if (wait > 0)                               // Se o frame foi mais rápido que isso...
      delay(wait);                              // ...espera o restante
  }
}

#endif                       // Fim da guarda de inclusão
