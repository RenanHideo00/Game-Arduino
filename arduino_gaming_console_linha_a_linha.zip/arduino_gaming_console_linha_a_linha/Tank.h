#ifndef TANK_H               // Guarda de inclusão: só compila se TANK_H ainda não foi definido
#define TANK_H               // Define TANK_H para o arquivo não ser incluído duas vezes

#include <Arduino.h>         // Funções básicas do Arduino (millis, delay, random, constrain, itoa...)
#include <U8g2lib.h>         // Biblioteca gráfica do display OLED

// As linhas "extern" avisam que estas coisas já existem no arquivo principal (.ino)
extern U8G2_SSD1306_128X64_NONAME_F_HW_I2C u8g2;     // O objeto do display
extern bool btnPressed(uint8_t pin);                 // Detecta o instante em que um botão é apertado
extern bool btnHeld(uint8_t pin);                    // Detecta se um botão está sendo segurado
extern void beep(uint16_t freq, uint16_t ms);        // Toca um som no buzzer
extern void waitRelease();                           // Espera soltar todos os botões
extern void centreStr(const char *s, uint8_t y);     // Escreve texto centralizado
extern void gameOver(uint16_t score);                // Tela de Game Over com a pontuação

#define MAX_ENEMY_TANKS 3    // Número máximo de tanques inimigos ao mesmo tempo

// Estrutura que representa um tanque (do jogador ou inimigo)
struct Tank {
  float x, y;                // Posição do tanque
  int8_t dx, dy; // Direction: 0:UP, 1:RIGHT, 2:DOWN, 3:LEFT
                             // Direção em que o tanque aponta: dx/dy valem -1, 0 ou 1
                             // (o comentário original fala em 0 a 3, mas o código usa -1/0/1)
  bool active;               // true = tanque existe; false = vaga livre
  uint32_t lastMove;         // Momento da última troca de direção (usado nos inimigos)
};

// Estrutura que representa um tiro de tanque
struct TankBullet {
  float x, y;                // Posição do tiro
  int8_t dx, dy;             // Direção do tiro (-1, 0 ou 1 em cada eixo)
  bool active;               // true = tiro existe
};

// Função principal do jogo; retorna quando o jogador é atingido.
// ATENÇÃO: este jogo NÃO está ligado ao menu do arquivo principal (não há #include "Tank.h",
// item no menu nem case no switch), então game_tank() nunca é chamada até isso ser adicionado.
void game_tank() {
  // Inicializa o jogador na ordem dos campos: x=64, y=50, dx=0, dy=true (vale 1, ou seja, apontando para baixo),
  // active=0 (false; o campo não é usado para o jogador), lastMove=0
  Tank player = {64, 50, 0, true, 0};
  Tank enemies[MAX_ENEMY_TANKS];           // Vetor com os tanques inimigos
  for (int i = 0; i < MAX_ENEMY_TANKS; i++)
    enemies[i].active = false;             // No início não há nenhum inimigo na tela

  TankBullet pBullet = {0, 0, 0, 0, false};   // Tiro do jogador (só 1 por vez), começa inativo
  TankBullet eBullets[MAX_ENEMY_TANKS];       // Tiros inimigos (1 para cada tanque inimigo)
  for (int i = 0; i < MAX_ENEMY_TANKS; i++)
    eBullets[i].active = false;            // Todos começam inativos

  uint16_t score = 0;                      // Pontuação
  uint32_t lastSpawn = 0;                  // Momento em que o último inimigo apareceu
  uint32_t lastFrame = millis();           // Momento do último frame (para calcular dt)

  // ── Tela de instruções ──
  u8g2.clearBuffer();                      // Limpa o buffer da tela
  u8g2.setFont(u8g2_font_ncenB10_tr);      // Fonte grande para o título
  centreStr("TANK BATTLE", 24);            // Título centralizado
  u8g2.setFont(u8g2_font_6x10_tr);         // Fonte pequena para as instruções
  centreStr("D-pad = Move", 40);           // Os 4 botões movem o tanque
  centreStr("LEFT = Fire", 52);            // ESQUERDA também atira
  u8g2.sendBuffer();                       // Envia o buffer para o display
  delay(1500);                             // Deixa o jogador ler por 1,5 segundo
  waitRelease();                           // Garante que nenhum botão esteja apertado ao começar

  // ── Loop principal do jogo (1 volta = 1 frame) ──
  while (true) {
    uint32_t now = millis();               // Hora atual em ms
    float dt = (now - lastFrame) / 20.0f;  // Fator de tempo desde o último frame (≈1.0 a 20 ms)
    lastFrame = now;                       // Guarda a hora deste frame

    // Player input
    // Movimento do jogador: só uma direção por vez (else if). Além de mover,
    // o botão define para onde o tanque aponta (dx, dy).
    if (btnHeld(BTN_UP)) {
      player.y -= 1.5f * dt;               // Sobe 1,5 px por frame
      player.dx = 0;
      player.dy = -1;                      // Aponta para cima
    } else if (btnHeld(BTN_DOWN)) {
      player.y += 1.5f * dt;               // Desce
      player.dx = 0;
      player.dy = 1;                       // Aponta para baixo
    } else if (btnHeld(BTN_LEFT)) {
      player.x -= 1.5f * dt;               // Vai para a esquerda
      player.dx = -1;                      // Aponta para a esquerda
      player.dy = 0;
    } else if (btnHeld(BTN_RIGHT)) {
      player.x += 1.5f * dt;               // Vai para a direita
      player.dx = 1;                       // Aponta para a direita
      player.dy = 0;
    }

    // Mantém o tanque (8x8 pixels) dentro da tela
    player.x = constrain(player.x, 0, SCREEN_W - 8);
    player.y = constrain(player.y, 0, SCREEN_H - 8);

    // Tiro do jogador: ESQUERDA (no instante do aperto) e só se não houver outro tiro ativo
    if (btnPressed(BTN_LEFT) && !pBullet.active) {
      pBullet.x = player.x + 3;            // O tiro sai do centro do tanque
      pBullet.y = player.y + 3;
      pBullet.dx = player.dx;              // ...na direção em que o tanque aponta
      pBullet.dy = player.dy;
      pBullet.active = true;               // Ativa o tiro
      beep(1200, 20);                      // Som de tiro
    }

    // Spawn enemies
    // A cada 3 segundos, cria um novo inimigo se houver vaga
    if (now - lastSpawn > 3000) {
      for (int i = 0; i < MAX_ENEMY_TANKS; i++) {
        if (!enemies[i].active) {                  // Achou uma vaga livre?
          enemies[i].x = random(0, SCREEN_W - 8);  // Aparece em X aleatório...
          enemies[i].y = 0;                        // ...no topo da tela
          enemies[i].dx = 0;
          enemies[i].dy = 1;                       // ...andando para baixo
          enemies[i].active = true;                // Ativa o inimigo
          enemies[i].lastMove = now;               // Marca o momento da criação
          lastSpawn = now;                         // Reinicia o tempo de spawn
          break;                                   // Cria só um inimigo por vez
        }
      }
    }

    // Move enemies & enemy fire
    for (int i = 0; i < MAX_ENEMY_TANKS; i++) {
      if (!enemies[i].active)              // Inimigo inativo: pula
        continue;

      // A cada 1 segundo o inimigo escolhe uma direção aleatória
      if (now - enemies[i].lastMove > 1000) {
        int dir = random(0, 4);            // Sorteia: 0 = cima, 1 = direita, 2 = baixo, 3 = esquerda
        if (dir == 0) {
          enemies[i].dx = 0;
          enemies[i].dy = -1;
        } else if (dir == 1) {
          enemies[i].dx = 1;
          enemies[i].dy = 0;
        } else if (dir == 2) {
          enemies[i].dx = 0;
          enemies[i].dy = 1;
        } else {
          enemies[i].dx = -1;
          enemies[i].dy = 0;
        }
        enemies[i].lastMove = now;         // Anota o momento da troca

        // Enemy fire
        // Ao trocar de direção, o inimigo também atira (se o tiro dele estiver livre)
        if (!eBullets[i].active) {
          eBullets[i].x = enemies[i].x + 3;        // O tiro sai do centro do inimigo
          eBullets[i].y = enemies[i].y + 3;
          eBullets[i].dx = enemies[i].dx;          // ...na direção em que ele aponta
          eBullets[i].dy = enemies[i].dy;
          eBullets[i].active = true;
        }
      }

      enemies[i].x += enemies[i].dx * 0.8f * dt;   // Move o inimigo (0,8 px por frame: mais lento que o jogador)
      enemies[i].y += enemies[i].dy * 0.8f * dt;
      enemies[i].x = constrain(enemies[i].x, 0, SCREEN_W - 8);   // Mantém dentro da tela
      enemies[i].y = constrain(enemies[i].y, 0, SCREEN_H - 8);
    }

    // Move bullets
    if (pBullet.active) {                  // Tiro do jogador
      pBullet.x += pBullet.dx * 3.0f * dt; // Anda 3 px por frame na direção do disparo
      pBullet.y += pBullet.dy * 3.0f * dt;
      if (pBullet.x < 0 || pBullet.x > SCREEN_W || pBullet.y < 0 ||
          pBullet.y > SCREEN_H)            // Saiu da tela?
        pBullet.active = false;            // Desativa o tiro
    }
    for (int i = 0; i < MAX_ENEMY_TANKS; i++) {   // Tiros inimigos
      if (eBullets[i].active) {
        eBullets[i].x += eBullets[i].dx * 2.0f * dt;   // Anda 2 px por frame (mais lento que o do jogador)
        eBullets[i].y += eBullets[i].dy * 2.0f * dt;
        if (eBullets[i].x < 0 || eBullets[i].x > SCREEN_W ||
            eBullets[i].y < 0 || eBullets[i].y > SCREEN_H)   // Saiu da tela?
          eBullets[i].active = false;                        // Desativa o tiro
      }
    }

    // Bullet collisions
    // Tiro do jogador acertando um inimigo
    if (pBullet.active) {
      for (int i = 0; i < MAX_ENEMY_TANKS; i++) {
        // Se o tiro está dentro do quadrado 8x8 do inimigo...
        if (enemies[i].active && pBullet.x > enemies[i].x &&
            pBullet.x < enemies[i].x + 8 && pBullet.y > enemies[i].y &&
            pBullet.y < enemies[i].y + 8) {
          enemies[i].active = false;       // ...destrói o inimigo
          pBullet.active = false;          // ...o tiro some
          score += 50;                     // ...ganha 50 pontos
          beep(800, 40);                   // ...som de explosão
        }
      }
    }
    // Tiro inimigo acertando o jogador
    for (int i = 0; i < MAX_ENEMY_TANKS; i++) {
      if (eBullets[i].active && eBullets[i].x > player.x &&
          eBullets[i].x < player.x + 8 && eBullets[i].y > player.y &&
          eBullets[i].y < player.y + 8) {
        gameOver(score);                   // Foi atingido: mostra Game Over
        return;                            // Encerra o jogo e volta ao menu
      }
    }

    // ── Draw ──
    u8g2.clearBuffer();                    // Limpa o buffer para desenhar o novo quadro

    // Draw Player
    u8g2.drawFrame((int)player.x, (int)player.y, 8, 8);   // Corpo do tanque: contorno 8x8
    // Canhão: uma linha de 3 px saindo do lado para onde o tanque aponta
    if (player.dy == -1)
      u8g2.drawVLine((int)player.x + 3, (int)player.y - 2, 3);   // Para cima
    else if (player.dy == 1)
      u8g2.drawVLine((int)player.x + 3, (int)player.y + 7, 3);   // Para baixo
    else if (player.dx == -1)
      u8g2.drawHLine((int)player.x - 2, (int)player.y + 3, 3);   // Para a esquerda
    else
      u8g2.drawHLine((int)player.x + 7, (int)player.y + 3, 3);   // Para a direita

    // Draw Enemies
    u8g2.setDrawColor(1);                  // Cor normal (pixel aceso)
    for (int i = 0; i < MAX_ENEMY_TANKS; i++) {
      if (enemies[i].active) {
        u8g2.drawBox((int)enemies[i].x, (int)enemies[i].y, 8, 8);   // Inimigo: quadrado cheio 8x8
        u8g2.setDrawColor(0);              // Cor 0 = apagar pixel
        u8g2.drawPixel((int)enemies[i].x + 3, (int)enemies[i].y + 3);  // Furinho no centro (diferencia do jogador)
        u8g2.setDrawColor(1);              // Volta à cor normal
      }
    }

    // Draw Bullets
    if (pBullet.active)
      u8g2.drawDisc((int)pBullet.x, (int)pBullet.y, 1);   // Tiro do jogador: círculo pequeno
    for (int i = 0; i < MAX_ENEMY_TANKS; i++)
      if (eBullets[i].active)
        u8g2.drawPixel((int)eBullets[i].x, (int)eBullets[i].y);  // Tiro inimigo: 1 pixel

    // Score
    u8g2.setFont(u8g2_font_6x10_tr);       // Fonte do placar
    char sc[6];                            // Texto onde o número será guardado
    itoa(score, sc, 10);                   // Converte a pontuação em texto (base 10)
    u8g2.drawStr(2, 10, sc);               // Pontuação no canto superior esquerdo

    u8g2.sendBuffer();                     // Envia o quadro pronto ao display

    // Controle de velocidade: tenta manter ~40 frames por segundo (25 ms por frame)
    int32_t wait = 25 - (int32_t)(millis() - now);   // Quanto falta para completar 25 ms
    if (wait > 0)                          // Se o frame foi mais rápido que isso...
      delay(wait);                         // ...espera o restante
  }
}

#endif                       // Fim da guarda de inclusão
