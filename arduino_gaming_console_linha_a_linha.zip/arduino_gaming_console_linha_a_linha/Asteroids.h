#ifndef ASTEROIDS_H          // Guarda de inclusão: só compila este arquivo se ASTEROIDS_H ainda não foi definido
#define ASTEROIDS_H          // Define ASTEROIDS_H, evitando que o arquivo seja incluído duas vezes

#include <Arduino.h>         // Funções básicas do Arduino (millis, delay, random...)
#include <U8g2lib.h>         // Biblioteca gráfica do display OLED

// As linhas "extern" avisam que estas coisas já existem no arquivo principal (.ino).
// Assim este jogo pode usá-las sem redefini-las.
extern U8G2_SSD1306_128X64_NONAME_F_HW_I2C u8g2;     // O objeto do display
extern bool btnPressed(uint8_t pin);                 // Detecta o instante em que um botão é apertado
extern bool btnHeld(uint8_t pin);                    // Detecta se um botão está sendo segurado
extern void beep(uint16_t freq, uint16_t ms);        // Toca um som no buzzer
extern void waitRelease();                           // Espera soltar todos os botões
extern void centreStr(const char *s, uint8_t y);     // Escreve texto centralizado
extern void gameOver(uint16_t score);                // Tela de Game Over com a pontuação

#define MAX_AST 8            // Número máximo de asteroides na tela ao mesmo tempo

// Estrutura que representa um asteroide
struct Rock {
  float x, y, spd;           // Posição (x, y) e velocidade horizontal (spd)
  uint8_t w, h;              // Largura e altura do asteroide em pixels
  bool on;                   // true = asteroide ativo (existe); false = vaga livre
};

// Função principal do jogo; é chamada pelo menu e retorna quando o jogador perde
void game_asteroids() {
  const int SHIP_W = 9, SHIP_H = 8;           // Tamanho da nave em pixels (usado nas colisões)
  int shipY = SCREEN_H / 2 - SHIP_H / 2;      // Posição vertical inicial da nave: no meio da tela

  Rock rocks[MAX_AST];                        // Vetor com todos os asteroides possíveis
  for (auto &r : rocks)                       // Percorre cada asteroide do vetor...
    r.on = false;                             // ...e o marca como inativo (nenhum na tela no início)

  uint32_t score = 0;                         // Pontuação interna (aumenta a cada frame)
  uint32_t lastSpawn = 0;                     // Momento (em ms) em que o último asteroide nasceu
  uint32_t lastFrame = millis();              // Momento do último frame (para calcular o tempo entre frames)
  uint32_t spawnGap = 900;                    // Intervalo entre o nascimento de asteroides (começa em 900 ms)

  const uint8_t starX[8] = {20, 45, 70, 95, 110, 35, 60, 85};  // Posições X das estrelas de fundo
  const uint8_t starY[8] = {8, 24, 12, 40, 55, 50, 36, 20};    // Posições Y das estrelas de fundo

  // ── Tela de instruções ──
  u8g2.clearBuffer();                         // Limpa o buffer da tela
  u8g2.setFont(u8g2_font_ncenB10_tr);         // Fonte grande para o título
  centreStr("ASTEROIDS", 24);                 // Título centralizado
  u8g2.setFont(u8g2_font_6x10_tr);            // Fonte pequena para as instruções
  centreStr("UP/DOWN to dodge", 40);          // Explica os controles
  centreStr("Survive as long", 52);           // Objetivo (linha 1)
  centreStr("as you can!", 62);               // Objetivo (linha 2)
  u8g2.sendBuffer();                          // Envia o buffer para o display
  delay(1600);                                // Deixa o jogador ler por 1,6 segundo
  waitRelease();                              // Garante que nenhum botão esteja apertado ao começar

  // ── Loop principal do jogo (1 volta = 1 frame) ──
  while (true) {
    uint32_t now = millis();                  // Hora atual em ms
    float dt = (now - lastFrame) / 30.0f;     // Fator de tempo: quanto tempo passou desde o último frame (≈1.0 a 30 ms)
    lastFrame = now;                          // Guarda a hora deste frame para o próximo cálculo

    // Movimento da nave
    if (btnHeld(BTN_UP))                      // Se CIMA está segurado...
      shipY = max(0, shipY - 3);              // ...sobe 3 pixels, sem passar do topo (0)
    if (btnHeld(BTN_DOWN))                    // Se BAIXO está segurado...
      shipY = min(SCREEN_H - SHIP_H, shipY + 3); // ...desce 3 pixels, sem passar da borda de baixo

    score++;                                  // Aumenta a pontuação a cada frame sobrevivido
    spawnGap = max(300UL, 900UL - score / 100); // Dificuldade: o intervalo entre asteroides diminui aos poucos, até o mínimo de 300 ms

    // Criação de novos asteroides
    if (now - lastSpawn > spawnGap) {         // Se já passou tempo suficiente desde o último...
      lastSpawn = now;                        // ...anota o momento deste nascimento
      for (auto &r : rocks) {                 // Procura uma vaga livre no vetor
        if (!r.on) {                          // Achou um asteroide inativo?
          r.x = SCREEN_W + 4;                 // Nasce logo fora da borda direita da tela
          r.y = random(2, SCREEN_H - 14);     // Altura aleatória (entre 2 e 49)
          r.w = random(5, 13);                // Largura aleatória (5 a 12 pixels)
          r.h = random(5, 11);                // Altura aleatória (5 a 10 pixels)
          r.spd = random(18, 40) / 10.0f;     // Velocidade aleatória (1,8 a 3,9 pixels por frame)
          r.on = true;                        // Ativa o asteroide
          break;                              // Sai do for: cria só um asteroide por vez
        }
      }
    }

    // Atualização dos asteroides e colisões
    for (auto &r : rocks) {                   // Para cada asteroide...
      if (!r.on)                              // ...se estiver inativo,
        continue;                             // ...pula para o próximo
      r.x -= r.spd * dt;                      // Move para a esquerda (velocidade × fator de tempo)
      if (r.x + r.w < 0) {                    // Se saiu totalmente pela esquerda da tela...
        r.on = false;                         // ...desativa (libera a vaga)
        continue;                             // ...e segue para o próximo
      }
      // Teste de colisão entre retângulos (nave está na coluna x=2 até x=2+SHIP_W):
      // há batida se os dois se sobrepõem na horizontal E na vertical
      if (r.x < 2 + SHIP_W && r.x + r.w > 2 && r.y < shipY + SHIP_H &&
          r.y + r.h > shipY) {
        gameOver(score / 10);                 // Bateu: mostra Game Over (pontuação dividida por 10 para ficar menor)
        return;                               // Encerra o jogo e volta ao menu
      }
    }

    // ── Desenho do frame ──
    u8g2.clearBuffer();                       // Limpa o buffer para desenhar o novo quadro
    for (int i = 0; i < 8; i++)               // Para cada uma das 8 estrelas...
      u8g2.drawPixel(starX[i], starY[i]);     // ...desenha um pixel na sua posição

    // Nave: três linhas formando um triângulo
    u8g2.drawLine(2, shipY + 4, 10, shipY);         // Lado de cima
    u8g2.drawLine(2, shipY + 4, 10, shipY + 8);     // Lado de baixo
    u8g2.drawLine(10, shipY, 10, shipY + 8);        // Lado vertical
    // Chama do motor: alterna entre dois desenhos a cada 120 ms
    if ((now / 120) % 2 == 0) {                     // Em "ciclos pares"...
      u8g2.drawLine(0, shipY + 3, 2, shipY + 4);    // ...chama grande (duas linhas)
      u8g2.drawLine(0, shipY + 5, 2, shipY + 4);
    } else {                                        // Nos "ciclos ímpares"...
      u8g2.drawPixel(1, shipY + 4);                 // ...chama pequena (um pixel)
    }

    // Desenho dos asteroides
    for (auto &r : rocks) {                   // Para cada asteroide...
      if (!r.on)                              // ...se inativo,
        continue;                             // ...não desenha
      int rx = (int)r.x, ry = (int)r.y;       // Converte a posição decimal para pixels inteiros
      u8g2.drawFrame(rx, ry, r.w, r.h);       // Desenha o contorno retangular
      u8g2.drawPixel(rx, ry);                 // Reforça os 4 cantos
      u8g2.drawPixel(rx + r.w - 1, ry);       // (canto superior direito)
      u8g2.drawPixel(rx, ry + r.h - 1);       // (canto inferior esquerdo)
      u8g2.drawPixel(rx + r.w - 1, ry + r.h - 1); // (canto inferior direito)
    }

    // Placar no canto superior direito
    u8g2.setFont(u8g2_font_5x7_tr);           // Fonte bem pequena para o placar
    char sc[8];                               // Texto onde o número será guardado
    ltoa(score / 10, sc, 10);                 // Converte o número (score/10) em texto, base 10
    uint8_t sw = u8g2.getStrWidth(sc);        // Mede a largura do texto
    u8g2.drawStr(SCREEN_W - sw - 2, 8, sc);   // Escreve alinhado à direita, com 2 px de margem

    u8g2.sendBuffer();                        // Envia o quadro pronto ao display

    // Controle de velocidade: tenta manter ~30 frames por segundo (33 ms por frame)
    int32_t wait = 33 - (int32_t)(millis() - now); // Quanto falta para completar 33 ms
    if (wait > 0)                             // Se o frame foi mais rápido que isso...
      delay(wait);                            // ...espera o restante do tempo
  }
}

#endif                       // Fim da guarda de inclusão
