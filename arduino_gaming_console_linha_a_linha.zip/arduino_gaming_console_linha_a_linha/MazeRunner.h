#ifndef MAZERUNNER_H         // Guarda de inclusão: só compila se MAZERUNNER_H ainda não foi definido
#define MAZERUNNER_H         // Define MAZERUNNER_H para o arquivo não ser incluído duas vezes

#include <Arduino.h>         // Funções básicas do Arduino (millis, delay, pgm_read_byte, itoa...)
#include <U8g2lib.h>         // Biblioteca gráfica do display OLED

// As linhas "extern" avisam que estas coisas já existem no arquivo principal (.ino)
extern U8G2_SSD1306_128X64_NONAME_F_HW_I2C u8g2;     // O objeto do display
extern bool btnPressed(uint8_t pin);                 // Detecta o instante em que um botão é apertado
extern bool btnHeld(uint8_t pin);                    // Detecta se um botão está sendo segurado
extern void beep(uint16_t freq, uint16_t ms);        // Toca um som no buzzer
extern void waitRelease();                           // Espera soltar todos os botões
extern void centreStr(const char *s, uint8_t y);     // Escreve texto centralizado
// (Este jogo não usa gameOver(): não existe "perder", só terminar o labirinto)

#define MZ_COLS 16           // Número de colunas do labirinto (células)
#define MZ_ROWS 8            // Número de linhas do labirinto (células)
#define MZ_CS 7              // Tamanho de cada célula em pixels (Cell Size)

// Mapa do labirinto. Cada número descreve as PAREDES de uma célula, usando bits:
//   1 = parede em cima,  2 = parede à direita,
//   4 = parede embaixo,  8 = parede à esquerda
// Os valores são somados: ex.: 11 = 1 + 2 + 8 (cima + direita + esquerda).
// PROGMEM guarda o mapa na memória flash (e não na RAM, que é pequena).
const uint8_t MAZE[MZ_ROWS][MZ_COLS] PROGMEM = {
    {11, 11, 9, 5, 5, 5, 5, 3, 9, 5, 5, 5, 5, 3, 9, 3},
    {10, 12, 4, 5, 7, 9, 3, 12, 4, 5, 7, 9, 3, 10, 10, 10},
    {12, 5, 5, 5, 3, 10, 12, 3, 9, 5, 3, 10, 10, 12, 2, 10},
    {13, 5, 5, 3, 12, 6, 11, 12, 6, 11, 12, 6, 12, 3, 14, 10},
    {9, 5, 3, 8, 7, 9, 4, 5, 1, 4, 1, 5, 7, 12, 5, 2},
    {10, 13, 4, 2, 9, 6, 9, 3, 10, 9, 6, 9, 5, 5, 5, 6},
    {8, 5, 3, 14, 10, 13, 6, 10, 10, 12, 7, 12, 5, 5, 5, 3},
    {12, 7, 12, 5, 4, 5, 5, 6, 12, 5, 5, 5, 5, 5, 5, 6}};

// Função principal do jogo; é chamada pelo menu e retorna quando o jogador chega à saída
void game_maze() {
  // px, py = posição do jogador (coluna, linha); ex, ey = posição da saída (canto inferior direito)
  int px = 0, py = 0, ex = MZ_COLS - 1, ey = MZ_ROWS - 1;
  // startTime = momento em que o jogo começou; lastMove = momento do último passo dado
  uint32_t startTime = millis(), lastMove = 0;
  uint16_t moveDelay = 160;        // Tempo mínimo (ms) entre um passo e outro

  // ── Tela de instruções ──
  u8g2.clearBuffer();                          // Limpa o buffer da tela
  u8g2.setFont(u8g2_font_ncenB10_tr);          // Fonte grande para o título
  centreStr("MAZE", 22);                       // Título centralizado
  u8g2.setFont(u8g2_font_6x10_tr);             // Fonte pequena para as instruções
  centreStr("Reach the E xit!", 38);           // Objetivo: chegar à saída (marcada com "E")
  centreStr("Use buttons to move", 52);        // Explica os controles
  u8g2.sendBuffer();                           // Envia o buffer para o display
  delay(1400);                                 // Deixa o jogador ler por 1,4 segundo
  waitRelease();                               // Garante que nenhum botão esteja apertado ao começar

  // ── Loop principal do jogo ──
  while (true) {
    uint32_t now = millis();                   // Hora atual em ms

    // Movimento: só permite um novo passo se já passaram 160 ms do anterior
    if (now - lastMove > moveDelay) {
      uint8_t walls = pgm_read_byte(&MAZE[py][px]); // Lê da flash as paredes da célula onde o jogador está
      bool moved = false;                      // Indica se o jogador andou neste ciclo
      if (btnHeld(BTN_UP) && !(walls & 1) && py > 0) {          // CIMA segurado, sem parede em cima e não está na borda
        py--;                                  // Sobe uma célula
        moved = true;
      }
      if (btnHeld(BTN_RIGHT) && !(walls & 2) && px < MZ_COLS - 1) { // DIREITA segurado, sem parede à direita
        px++;                                  // Vai uma célula para a direita
        moved = true;
      }
      if (btnHeld(BTN_DOWN) && !(walls & 4) && py < MZ_ROWS - 1) {  // BAIXO segurado, sem parede embaixo
        py++;                                  // Desce uma célula
        moved = true;
      }
      if (btnHeld(BTN_LEFT) && !(walls & 8) && px > 0) {        // ESQUERDA segurado, sem parede à esquerda
        px--;                                  // Vai uma célula para a esquerda
        moved = true;
      }
      if (moved) {                             // Se andou...
        beep(900, 15);                         // ...toca um som curto de passo
        lastMove = now;                        // ...e anota o momento (para respeitar o intervalo)
      }
    }

    // Verifica se o jogador chegou à saída
    if (px == ex && py == ey) {
      uint16_t secs = (millis() - startTime) / 1000;   // Tempo total em segundos
      u8g2.clearBuffer();                      // Limpa a tela
      u8g2.setFont(u8g2_font_ncenB10_tr);      // Fonte grande
      centreStr("ESCAPED!", 26);               // Mensagem de vitória
      u8g2.setFont(u8g2_font_6x10_tr);         // Fonte pequena
      char buf[24];                            // Texto para o tempo
      snprintf(buf, sizeof(buf), "Time: %us", secs);   // Monta "Time: Ns"
      centreStr(buf, 42);                      // Mostra o tempo
      centreStr("Press any button", 58);       // Instrução
      u8g2.sendBuffer();                       // Envia para o display
      beep(1047, 80);                          // Pequena melodia de vitória (3 notas subindo)
      delay(90);
      beep(1319, 80);
      delay(90);
      beep(1568, 200);
      delay(400);
      waitRelease();                           // Espera soltar os botões
      // Espera o jogador apertar qualquer botão
      while (!btnHeld(BTN_UP) && !btnHeld(BTN_DOWN) && !btnHeld(BTN_LEFT) &&
             !btnHeld(BTN_RIGHT))
        delay(15);
      waitRelease();                           // Espera soltar antes de voltar ao menu
      return;                                  // Encerra o jogo
    }

    // ── Desenho do labirinto ──
    const int OX = 8, OY = 4;                  // Deslocamento (margem) para centralizar o labirinto na tela
    u8g2.clearBuffer();                        // Limpa o buffer
    for (int r = 0; r < MZ_ROWS; r++) {        // Para cada linha de células...
      for (int c = 0; c < MZ_COLS; c++) {      // ...e cada coluna...
        uint8_t w = pgm_read_byte(&MAZE[r][c]);        // Lê as paredes desta célula
        int cx = OX + c * MZ_CS, cy = OY + r * MZ_CS;  // Posição (em pixels) do canto superior esquerdo da célula
        if (w & 1)                                     // Tem parede em cima?
          u8g2.drawHLine(cx, cy, MZ_CS + 1);           // Desenha linha horizontal no topo da célula
        if (w & 2)                                     // Tem parede à direita?
          u8g2.drawVLine(cx + MZ_CS, cy, MZ_CS + 1);   // Desenha linha vertical na direita
        if (w & 4)                                     // Tem parede embaixo?
          u8g2.drawHLine(cx, cy + MZ_CS, MZ_CS + 1);   // Desenha linha horizontal na base
        if (w & 8)                                     // Tem parede à esquerda?
          u8g2.drawVLine(cx, cy, MZ_CS + 1);           // Desenha linha vertical na esquerda
      }
    }
    u8g2.setFont(u8g2_font_5x7_tr);            // Fonte bem pequena
    u8g2.drawStr(OX + ex * MZ_CS + 1, OY + ey * MZ_CS + 6, "E");  // Letra "E" marcando a saída
    // Jogador: círculo de raio 2 no centro da célula atual
    u8g2.drawDisc(OX + px * MZ_CS + MZ_CS / 2, OY + py * MZ_CS + MZ_CS / 2, 2);
    char tbuf[8];                              // Texto do cronômetro
    itoa((millis() - startTime) / 1000, tbuf, 10);     // Converte os segundos decorridos em texto
    u8g2.drawStr(SCREEN_W - u8g2.getStrWidth(tbuf) - 1, 8, tbuf);  // Escreve alinhado à direita, no topo
    u8g2.sendBuffer();                         // Envia o quadro pronto ao display
    delay(20);                                 // Pausa de 20 ms entre frames (~50 por segundo)
  }
}

#endif                       // Fim da guarda de inclusão
