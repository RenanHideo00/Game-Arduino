#ifndef PONG_H               // Guarda de inclusão: só compila se PONG_H ainda não foi definido
#define PONG_H               // Define PONG_H para o arquivo não ser incluído duas vezes

#include <Arduino.h>         // Funções básicas do Arduino (delay, constrain, itoa...)
#include <U8g2lib.h>         // Biblioteca gráfica do display OLED

// As linhas "extern" avisam que estas coisas já existem no arquivo principal (.ino)
extern U8G2_SSD1306_128X64_NONAME_F_HW_I2C u8g2;     // O objeto do display
extern bool btnPressed(uint8_t pin);                 // Detecta o instante em que um botão é apertado
extern bool btnHeld(uint8_t pin);                    // Detecta se um botão está sendo segurado
extern void beep(uint16_t freq, uint16_t ms);        // Toca um som no buzzer
extern void waitRelease();                           // Espera soltar todos os botões
extern void centreStr(const char *s, uint8_t y);     // Escreve texto centralizado
// (Este jogo não usa gameOver(): termina com sua própria tela de vitória/derrota)

// Função principal do jogo; é chamada pelo menu e retorna quando alguém faz 7 pontos
void game_pong() {
  const int PAD_H = 14;      // Altura das raquetes
  const int PAD_W = 3;       // Largura das raquetes
  const int WIN = 7;         // Pontos necessários para vencer

  float bx = 64, by = 32;    // Posição da bolinha: começa no centro da tela
  float vx = 2.5f, vy = 1.8f; // Velocidade da bolinha em X e Y (pixels por frame)
  int pY = 25, cY = 25;      // Posição Y das raquetes: pY = jogador (esquerda), cY = computador (direita)
  int pScore = 0, cScore = 0; // Pontuação do jogador e do computador

  // ── Tela de instruções ──
  u8g2.clearBuffer();                      // Limpa o buffer da tela
  u8g2.setFont(u8g2_font_ncenB10_tr);      // Fonte grande para o título
  centreStr("PONG", 24);                   // Título centralizado
  u8g2.setFont(u8g2_font_6x10_tr);         // Fonte pequena para as instruções
  centreStr("UP/DOWN = move", 40);         // Explica os controles
  centreStr("First to 7 wins!", 54);       // Objetivo: primeiro a chegar a 7 pontos
  u8g2.sendBuffer();                       // Envia o buffer para o display
  delay(1500);                             // Deixa o jogador ler por 1,5 segundo
  waitRelease();                           // Garante que nenhum botão esteja apertado ao começar

  // ── Loop principal do jogo (1 volta = 1 frame) ──
  while (true) {
    // Movimento da raquete do jogador
    if (btnHeld(BTN_UP))                   // Se CIMA está segurado...
      pY = max(0, pY - 3);                 // ...sobe 3 px, sem passar do topo
    if (btnHeld(BTN_DOWN))                 // Se BAIXO está segurado...
      pY = min(SCREEN_H - PAD_H, pY + 3);  // ...desce 3 px, sem passar da base

    // Inteligência do computador: a raquete segue a altura da bolinha
    int mid = cY + PAD_H / 2;              // Centro da raquete do computador
    if (mid < (int)by - 1)                 // Se o centro está acima da bolinha...
      cY = min(SCREEN_H - PAD_H, cY + 2);  // ...desce 2 px (mais lento que o jogador, que anda 3)
    if (mid > (int)by + 1)                 // Se o centro está abaixo da bolinha...
      cY = max(0, cY - 2);                 // ...sobe 2 px

    bx += vx;                              // Move a bolinha na horizontal
    by += vy;                              // Move a bolinha na vertical

    // Rebote no teto e no chão
    if (by <= 0) {                         // Tocou o teto?
      vy = fabsf(vy);                      // Força vy positivo (passa a descer)
      by = 0;                              // Recoloca a bolinha dentro da tela
      beep(500, 15);                       // Som curto de rebote
    }
    if (by >= SCREEN_H - 3) {              // Tocou a base? (a bolinha tem 3 px de altura)
      vy = -fabsf(vy);                     // Força vy negativo (passa a subir)
      by = SCREEN_H - 3;                   // Recoloca a bolinha dentro da tela
      beep(500, 15);                       // Som curto de rebote
    }

    // Player Paddle Collision
    // Bolinha indo para a esquerda, na altura da raquete e alinhada com ela na horizontal
    if (vx < 0 && bx <= 4 + PAD_W && bx >= 4 && by + 2 >= pY &&
        by <= pY + PAD_H) {
      vx = fabsf(vx) * 1.05f;              // Inverte para a direita e acelera 5%
      // O ponto de impacto muda o ângulo: batendo longe do centro da raquete, vy muda mais
      vy += ((by - (pY + PAD_H / 2.0f)) / (PAD_H / 2.0f)) * 1.5f;
      vy = constrain(vy, -4.5f, 4.5f);     // Limita a velocidade vertical entre -4,5 e 4,5
      vx = min(vx, 5.0f);                  // Limita a velocidade horizontal a 5
      bx = 4 + PAD_W;                      // Coloca a bolinha logo à frente da raquete (evita bater de novo)
      beep(1000, 20);                      // Som de rebote na raquete do jogador
    }

    // Colisão com a raquete do computador (mesma lógica, do lado direito)
    if (bx >= 121 - PAD_W && bx <= 122 && by + 2 >= cY && by <= cY + PAD_H) {
      vx = -fabsf(vx) * 1.05f;             // Inverte para a esquerda e acelera 5%
      vy += ((by - (cY + PAD_H / 2.0f)) / (PAD_H / 2.0f)) * 1.2f;  // Muda o ângulo conforme o ponto de impacto
      vy = constrain(vy, -4.0f, 4.0f);     // Limita a velocidade vertical (um pouco menor que a do jogador)
      vx = max(vx, -5.0f);                 // Limita a velocidade horizontal a -5
      bx = 121 - PAD_W - 1;                // Coloca a bolinha logo à frente da raquete
      beep(900, 20);                       // Som de rebote na raquete do computador
    }

    // Ponto do computador: a bolinha passou pela esquerda
    if (bx < 0) {
      cScore++;                            // Computador ganha 1 ponto
      beep(200, 250);                      // Som grave (ponto perdido)
      bx = 64;                             // Reposiciona a bolinha no centro...
      by = 32;
      vx = 2.5f;                           // ...com a velocidade inicial (indo para a direita)
      vy = 1.8f;
      pY = 25;                             // Reposiciona as raquetes no meio
      cY = 25;
      delay(600);                          // Pausa curta antes de continuar
    }
    // Ponto do jogador: a bolinha passou pela direita
    if (bx > SCREEN_W) {
      pScore++;                            // Jogador ganha 1 ponto
      beep(1400, 100);                     // Som agudo (ponto ganho)
      bx = 64;                             // Reposiciona a bolinha no centro...
      by = 32;
      vx = -2.5f;                          // ...com a velocidade inicial (indo para a esquerda)
      vy = 1.8f;
      pY = 25;                             // Reposiciona as raquetes no meio
      cY = 25;
      delay(600);                          // Pausa curta antes de continuar
    }

    // Fim da partida: alguém chegou a 7 pontos
    if (pScore >= WIN || cScore >= WIN) {
      u8g2.clearBuffer();                  // Limpa a tela
      u8g2.setFont(u8g2_font_ncenB10_tr);  // Fonte grande
      centreStr(pScore >= WIN ? "YOU WIN!" : "CPU WINS", 28);  // Mostra quem venceu
      u8g2.setFont(u8g2_font_6x10_tr);     // Fonte pequena
      char buf[20];                        // Texto para o placar final
      snprintf(buf, sizeof(buf), "%d  :  %d", pScore, cScore); // Monta "jogador : computador"
      centreStr(buf, 44);                  // Mostra o placar
      centreStr("Press any button", 58);   // Instrução
      u8g2.sendBuffer();                   // Envia para o display
      if (pScore >= WIN) {                 // Se o jogador venceu...
        beep(1760, 100);                   // ...toca uma melodia de vitória
        delay(110);
        beep(1760, 100);
        delay(110);
        beep(2093, 300);
      } else {                             // Se o computador venceu...
        beep(300, 200);                    // ...toca um som grave de derrota
      }
      delay(400);                          // Pausa curta
      waitRelease();                       // Espera soltar os botões
      // Espera o jogador apertar qualquer botão
      while (!btnHeld(BTN_UP) && !btnHeld(BTN_DOWN) && !btnHeld(BTN_LEFT) &&
             !btnHeld(BTN_RIGHT))
        delay(15);
      waitRelease();                       // Espera soltar antes de voltar ao menu
      return;                              // Encerra o jogo
    }

    // ── Desenho do frame ──
    u8g2.clearBuffer();                    // Limpa o buffer para desenhar o novo quadro
    for (int y = 0; y < SCREEN_H; y += 6)  // Linha central pontilhada: um pixel a cada 6 px...
      u8g2.drawPixel(63, y);               // ...na coluna do meio da tela
    u8g2.drawBox(4, pY, PAD_W, PAD_H);     // Raquete do jogador (esquerda)
    u8g2.drawBox(121, cY, PAD_W, PAD_H);   // Raquete do computador (direita)
    u8g2.drawBox((int)bx, (int)by, 3, 3);  // Bolinha (quadrado 3x3)

    u8g2.setFont(u8g2_font_6x10_tr);       // Fonte do placar
    char ps[4], cs[4];                     // Textos para as duas pontuações
    itoa(pScore, ps, 10);                  // Converte a pontuação do jogador em texto
    itoa(cScore, cs, 10);                  // Converte a pontuação do computador em texto
    u8g2.drawStr(42, 10, ps);              // Placar do jogador, à esquerda da linha central
    u8g2.drawStr(78, 10, cs);              // Placar do computador, à direita da linha central
    u8g2.sendBuffer();                     // Envia o quadro pronto ao display
    delay(16);                             // Pausa de 16 ms entre frames (~60 por segundo)
  }
}

#endif                       // Fim da guarda de inclusão
